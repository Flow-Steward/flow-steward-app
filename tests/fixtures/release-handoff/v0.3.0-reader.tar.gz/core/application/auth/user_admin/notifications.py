"""Non-blocking notification policy for user administration."""

from __future__ import annotations

import logging
from collections.abc import Callable, Mapping
from typing import Any

LOGGER = logging.getLogger(__name__)
SIGNUP_DELIVERY_WARNING = (
    "User created, but the signup notification was not delivered. "
    "Check SYSTEM_EMAIL_* configuration and SMTP/Mailpit readiness."
)


def notify_signup_non_blocking(
    notifier: Callable[..., Any] | None,
    *,
    user_id: str,
    recipient: str,
    display_name: str,
    locale: str,
) -> str | None:
    if notifier is None:
        return None
    try:
        result = notifier(
            recipient=recipient,
            display_name=display_name,
            locale=locale,
        )
    except Exception:
        LOGGER.warning("Signup notification delivery failed for user_id=%s", user_id)
        return SIGNUP_DELIVERY_WARNING
    if isinstance(result, Mapping) and result.get("ok") is False:
        LOGGER.warning("Signup notification delivery failed for user_id=%s", user_id)
        return SIGNUP_DELIVERY_WARNING
    return None
