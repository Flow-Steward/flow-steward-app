"""Jobs application package."""
