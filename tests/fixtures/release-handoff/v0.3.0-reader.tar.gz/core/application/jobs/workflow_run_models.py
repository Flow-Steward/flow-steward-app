"""Stable, versioned public workflow-run models."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Literal

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_serializer,
    field_validator,
    model_validator,
)

PublicStepStatus = Literal[
    "in_progress",
    "awaiting_approval",
    "external_wait",
    "completed",
    "failed",
    "cancelled",
    "skipped",
]


class _PublicModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class _UtcTimestamps(_PublicModel):
    @field_validator("*", mode="after")
    @classmethod
    def _normalize_datetimes(cls, value: Any) -> Any:
        if not isinstance(value, datetime):
            return value
        if value.tzinfo is None:
            return value.replace(tzinfo=UTC)
        return value.astimezone(UTC)

    @field_serializer("*", when_used="json", check_fields=False)
    def _serialize_datetimes(self, value: Any) -> Any:
        if not isinstance(value, datetime):
            return value
        return value.astimezone(UTC).isoformat().replace("+00:00", "Z")


class PublicWorkflowStepV1(_UtcTimestamps):
    step_id: str
    phase_id: str
    occurrence: int = Field(ge=1)
    display_name: str | None = None
    step_kind: str
    status: PublicStepStatus
    started_at: datetime | None = None
    finished_at: datetime | None = None
    child_job_id: str | None = None


class PublicApprovalGateV1(_UtcTimestamps):
    approval_id: str
    job_id: str
    thread_id: str
    step_id: str | None = None
    phase_id: str | None = None
    message: str = ""
    content: dict[str, Any] = Field(default_factory=dict)
    allowed_actions: list[str] = Field(default_factory=list)
    created_at: datetime
    expires_at: datetime | None = None


class PublicWorkflowResultV1(_PublicModel):
    outputs: dict[str, Any] = Field(default_factory=dict)
    artifacts: dict[str, Any] = Field(default_factory=dict)


class PublicWorkflowErrorV1(_PublicModel):
    code: str
    message: str
    step_id: str | None = None
    phase_id: str | None = None
    occurrence: int | None = Field(default=None, ge=1)
    category: str
    retryable: bool
    details: dict[str, Any] = Field(default_factory=dict)


class WorkflowRunStateV1(_UtcTimestamps):
    schema_version: Literal["1"] = "1"
    job_id: str
    project_id: str
    workflow_id: str
    status: str
    terminal: bool
    active_steps: list[PublicWorkflowStepV1] = Field(default_factory=list)
    steps: list[PublicWorkflowStepV1] = Field(default_factory=list)
    approval: PublicApprovalGateV1 | None = None
    result: PublicWorkflowResultV1 | None = None
    error: PublicWorkflowErrorV1 | None = None
    queued_at: datetime | None = None
    started_at: datetime | None = None
    updated_at: datetime
    finished_at: datetime | None = None

    @model_validator(mode="after")
    def _terminal_payload_semantics(self) -> WorkflowRunStateV1:
        if not self.terminal:
            if self.finished_at is not None or self.result is not None or self.error is not None:
                raise ValueError("non-terminal workflow runs cannot expose terminal fields")
        elif self.status == "completed":
            if self.result is None or self.error is not None:
                raise ValueError("completed workflow runs require only result")
        elif self.result is not None:
            raise ValueError("unsuccessful workflow runs cannot expose result")
        return self


class PublicSnapshotRevision(_PublicModel):
    snapshot: WorkflowRunStateV1
    revision: int = Field(ge=1)
    marker_id: str | None = None
    changed: bool


__all__ = [
    "PublicApprovalGateV1",
    "PublicSnapshotRevision",
    "PublicStepStatus",
    "PublicWorkflowErrorV1",
    "PublicWorkflowResultV1",
    "PublicWorkflowStepV1",
    "WorkflowRunStateV1",
]
