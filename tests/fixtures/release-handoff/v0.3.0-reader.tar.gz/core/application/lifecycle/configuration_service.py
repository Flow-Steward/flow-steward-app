"""Application ownership for installed and pending deployment configuration."""

from __future__ import annotations

import re
from collections.abc import Mapping
from contextlib import suppress
from datetime import UTC, datetime
from ipaddress import ip_address
from itertools import pairwise
from pathlib import Path
from typing import Literal, NoReturn, Protocol
from uuid import uuid4

from cryptography import x509
from cryptography.hazmat.primitives import serialization
from pydantic import BaseModel, ConfigDict, Field, JsonValue, ValidationError, model_validator

from core.application.installer.redaction import redact_installer_text
from core.application.lifecycle.contracts import (
    CancellationToken,
    ComposeTarget,
    ConfigurationPatch,
    ConfigurationValidationResult,
    DeploymentConfig,
    LifecycleLockStatus,
    LifecycleOperationDefinition,
    LifecycleOperationJournal,
    LifecycleOperationKind,
    LifecycleOperationStatus,
    LifecycleOperationStep,
    profile_owned_environment,
)
from core.application.lifecycle.errors import LifecycleError
from core.application.lifecycle.operation_service import LifecycleOperationRunner
from core.application.lifecycle.ports import (
    HeartbeatSink,
    LifecycleState,
    ProgressSink,
    TechnicalSink,
)
from core.application.management.errors import ServicePreconditionError

_MESSAGE_FLOW_STEWARD_CONFIG_APPLY = "flow-steward config apply"
_MESSAGE_RETRY_FROM_THE_INSTALLED_FLOW_STEWARD_CLI_RUNTIME = (
    "Retry from the installed Flow Steward CLI runtime."
)
_SAFE_FAILURE_ACTION = re.compile(r"^[a-z][a-z0-9_]{0,127}$")

_BASE_SERVICES = (
    "traefik",
    "rabbitmq-fs",
    "pg-fs",
    "fs-mcp",
    "fs-app",
    "fs-extension-installer",
    "fs-worker",
    "control-plane",
)


# Where a Scalable installation keeps its trees, as its Compose defaults them.
_SCALABLE_HOST_TREES = {
    "FS_LOGS_DIR": "../../logs",
    "FS_EXTENSIONS_DIR": "../../extensions",
}


def _configuration_failure_details(cause: Exception) -> dict[str, object]:
    details: dict[str, object] = {}
    action = getattr(cause, "action", None)
    raw_detail = getattr(cause, "detail", None)
    if isinstance(action, str) and _SAFE_FAILURE_ACTION.fullmatch(action):
        details["failed_action"] = action
    if isinstance(raw_detail, str) and raw_detail.strip():
        detail = redact_installer_text(raw_detail.strip())[:600]
        if detail:
            details["failure_detail"] = detail
    return details


def _production_preserved_services(compact: bool) -> tuple[str, ...]:
    """Services whose data must survive a production stack operation."""
    return ("pg-fs", "compact-runtime") if compact else ("pg-fs",)


def _public_bind_host(public_host: str) -> str:
    normalized = public_host.strip().strip("[]").lower()
    if normalized in {"localhost", "127.0.0.1"}:
        return "127.0.0.1"
    if normalized == "::1":
        return "[::1]"
    return str(ip_address(0))


class _ClosedModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class ConfigShowRequest(_ClosedModel):
    """Read active and pending configuration without mutation."""


class ConfigProxyFragmentRequest(_ClosedModel):
    """Render the reverse-proxy fragment for the installed configuration."""


class ConfigProxyFragmentResult(_ClosedModel):
    """The fragment an operator pastes into their own proxy, and what it assumes."""

    proxy_kind: Literal["nginx", "apache"]
    proxy_placement: Literal["host", "docker"]
    public_host: str
    app_backend: str
    mcp_backend: str = ""
    fragment: str


class ConfigValidateRequest(_ClosedModel):
    """Validate active and pending configuration without mutation."""


class ConfigSetRequest(ConfigurationPatch):
    """Closed declarative patch accepted by the public config command."""

    @model_validator(mode="after")
    def refuse_data_placement(self) -> ConfigSetRequest:
        if self.data_placement is not None:
            raise ValueError(
                "data_placement is chosen by ./install.sh --deployment-profile, which switches "
                "the profile and keeps the data where it is; it is not set by hand."
            )
        return self


class ConfigApplyRequest(_ClosedModel):
    """Apply the sole pending declarative patch."""


class ConfigSecretState(_ClosedModel):
    """One secret name with presence only, never its value."""

    name: str
    state: Literal["configured", "missing"]


class ConfigShowResult(_ClosedModel):
    """Secret-free active configuration, pending patch, and exact diff."""

    active: DeploymentConfig
    pending: ConfigurationPatch | None = None
    pending_diff: dict[str, dict[str, JsonValue]] = Field(default_factory=dict)
    protected_setting_states: tuple[ConfigSecretState, ...] = ()


class ConfigSetResult(_ClosedModel):
    """The secret-free patch staged for later apply."""

    pending: ConfigurationPatch


class ConfigApplyCommandResult(_ClosedModel):
    """Public successful result from the shared lifecycle operation."""

    active: DeploymentConfig
    operation_id: str
    journal_path: str
    log_path: str
    snapshot_path: str = ""
    preservation_verified: bool = True
    runtime_restored: bool = False


class ConfigurationState(Protocol):
    pending_path: Path

    def read_active(self) -> DeploymentConfig | None: ...

    def write_active(self, config: DeploymentConfig) -> None: ...

    def read_pending(self) -> ConfigurationPatch | None: ...

    def read_pending_with_revision(self) -> tuple[ConfigurationPatch, str] | None: ...

    def write_pending(self, patch: ConfigurationPatch) -> None: ...

    def clear_pending(self) -> None: ...

    def pending_revision_matches(self, revision: str) -> bool: ...

    def clear_pending_if_revision(self, revision: str) -> bool: ...

    def save_snapshot(self, operation_id: str, config: DeploymentConfig) -> Path: ...

    def env_path(self, config: DeploymentConfig) -> Path: ...

    def read_env_values(self, path: Path) -> dict[str, str]: ...

    def read_durable_environment(self, config: DeploymentConfig) -> dict[str, str]: ...

    def build_environment(
        self,
        config: DeploymentConfig,
        existing: Mapping[str, str],
    ) -> dict[str, str]: ...

    def write_runtime_environment(self, path: Path, managed: Mapping[str, str]) -> None: ...

    def write_transition_runtime_environment(
        self,
        path: Path,
        managed: Mapping[str, str],
        *,
        source_path: Path,
    ) -> None: ...

    def transition_runtime_environment_matches(
        self,
        path: Path,
        managed: Mapping[str, str],
        *,
        source_path: Path,
        allow_installed_storage_credentials: bool = False,
    ) -> bool: ...

    def write_compose_environment(self, values: Mapping[str, str]) -> None: ...

    def begin_active_publication(
        self,
        previous: DeploymentConfig,
        candidate: DeploymentConfig,
        *,
        target_env_path: Path,
        compose_values: Mapping[str, str],
    ) -> str: ...

    def commit_active_publication(
        self,
        candidate: DeploymentConfig,
        *,
        revision: str,
        target_env_path: Path,
    ) -> None: ...

    def active_publication_matches(self, candidate: DeploymentConfig) -> bool: ...

    def project_name(self, config: DeploymentConfig) -> str: ...

    def transition_project_name(self, active: DeploymentConfig) -> str: ...

    def resolve_project_path(self, raw_path: str) -> Path: ...

    def secret_statuses(self, config: DeploymentConfig) -> Mapping[str, bool]: ...


class ConfigurationApplyGateway(Protocol):
    """Technical effects orchestrated by ``config apply``."""

    def validate_target(
        self,
        config: DeploymentConfig,
        target: ComposeTarget,
        environment: Mapping[str, str],
        managed_target: ComposeTarget | None = None,
    ) -> None: ...

    def capture_recovery(
        self,
        previous_target: ComposeTarget,
        candidate_target: ComposeTarget,
        *,
        operation_id: str,
    ) -> Mapping[str, object]: ...

    def recovery_available(self, operation_id: str) -> bool: ...

    def apply_artifacts(self, config: DeploymentConfig, *, operation_id: str) -> None: ...

    def restore_recovery(
        self,
        target: ComposeTarget,
        *,
        operation_id: str,
        snapshot: Mapping[str, object],
        output_sink: TechnicalSink | None = None,
    ) -> bool: ...

    def capture_manifest(
        self,
        config: DeploymentConfig,
        target: ComposeTarget,
        *,
        operation_id: str,
        stage: Literal["before", "after"],
    ) -> Mapping[str, object]: ...

    def validate_preservation_baseline(self, manifest: Mapping[str, object]) -> None: ...

    def runtime_images_match(
        self,
        target: ComposeTarget,
        snapshot: Mapping[str, object],
    ) -> bool: ...

    def runtime_image_drift(
        self,
        target: ComposeTarget,
        snapshot: Mapping[str, object],
    ) -> tuple[str, ...]: ...

    def load_manifest(
        self,
        operation_id: str,
        stage: Literal["before", "after"],
    ) -> Mapping[str, object] | None: ...

    def activate(
        self,
        previous: DeploymentConfig,
        config: DeploymentConfig,
        previous_target: ComposeTarget,
        target: ComposeTarget,
        runtime_snapshot: Mapping[str, object],
        *,
        source_environment: Mapping[str, str] | None = None,
    ) -> None: ...

    def healthy(self, config: DeploymentConfig, target: ComposeTarget) -> bool: ...

    def candidate_diagnostics(
        self,
        config: DeploymentConfig,
        target: ComposeTarget,
        output_sink: TechnicalSink,
    ) -> None: ...

    def recovery_healthy(
        self,
        config: DeploymentConfig,
        target: ComposeTarget,
        snapshot: Mapping[str, object],
    ) -> bool: ...

    def compare_manifests(
        self,
        before: Mapping[str, object],
        after: Mapping[str, object],
        *,
        profile_transition: bool = False,
    ) -> None: ...


class ConfigurationService:
    """Single application service for active and pending installed configuration."""

    def __init__(
        self,
        *,
        store: ConfigurationState,
        gateway: ConfigurationApplyGateway | None = None,
        lifecycle_state: LifecycleState | None = None,
        docker_host_project_root: Path | None = None,
    ) -> None:
        self.store = store
        self.gateway = gateway
        self.lifecycle_state = lifecycle_state
        self.docker_host_project_root = (
            Path(docker_host_project_root).resolve()
            if docker_host_project_root is not None
            else None
        )

    def read_active(self, *, required: bool = True) -> DeploymentConfig | None:
        try:
            config = self.store.read_active()
        except (OSError, ValueError, ValidationError) as exc:
            raise LifecycleError.stable_failure(
                code="configuration_invalid",
                cause="The installed configuration is unreadable or invalid.",
                remediation="Run flow-steward config validate and repair the reported fields.",
                step="configuration",
            ) from exc
        if config is None and required:
            raise LifecycleError.stable_failure(
                code="configuration_unavailable",
                cause="Flow Steward has not been installed.",
                remediation="Run ./install.sh.",
                step="configuration",
            )
        return config

    def read_pending(self) -> ConfigurationPatch | None:
        try:
            return self.store.read_pending()
        except (OSError, ValueError, ValidationError) as exc:
            raise LifecycleError.stable_failure(
                code="pending_configuration_invalid",
                cause="The pending configuration patch is unreadable or invalid.",
                remediation="Run flow-steward config set again with valid values.",
                step="configuration",
            ) from exc

    def proxy_fragment(
        self, request: ConfigProxyFragmentRequest | None = None
    ) -> ConfigProxyFragmentResult:
        """Render the operator's proxy fragment from the configuration already saved.

        AC17-R113: the renderer and its input validation have existed for some time and
        nothing reached them -- `render_proxy_fragment` had no caller in the product at
        all, only two test files, while the operations guide told an operator to open
        the source and call a Python function by hand. The installer offers "existing
        reverse proxy" beside the other two ingress modes, so that instruction is on a
        path the product invites people down.

        No new configuration surface: proxy kind, public host, backend host and ports
        are answers the installation already recorded.
        """
        del request
        active = self.read_active()
        assert active is not None
        if active.ingress_mode != "external_proxy":
            raise ServicePreconditionError(
                "This installation does not front itself with an external proxy.",
                payload={
                    "code": "ingress_mode_is_not_external_proxy",
                    "message": (
                        f"ingress_mode is {active.ingress_mode!r}; a proxy fragment is only "
                        "meaningful for 'external_proxy'."
                    ),
                    "details": {"ingress_mode": active.ingress_mode},
                },
            )
        app_backend, mcp_backend = self._proxy_backends(active)
        from core.application.lifecycle.proxy_renderer import (
            ProxyRenderConfig,
            render_proxy_fragment,
        )

        fragment = render_proxy_fragment(
            ProxyRenderConfig(
                kind=active.proxy_kind,
                deployment_profile=active.deployment_profile,
                public_host=active.public_host,
                app_backend=app_backend,
                mcp_backend=mcp_backend or None,
            )
        )
        return ConfigProxyFragmentResult(
            proxy_kind=active.proxy_kind,
            proxy_placement=active.proxy_placement,
            public_host=active.public_host,
            app_backend=app_backend,
            mcp_backend=mcp_backend,
            fragment=fragment,
        )

    def _proxy_backends(self, active: DeploymentConfig) -> tuple[str, str]:
        """Where the operator's proxy should send traffic, per placement and profile.

        Derived from the ingress overlays rather than assumed: host placement publishes
        the backend ports the operator answered, and docker placement joins the proxy
        network under the aliases infra/docker/*/ingress-external_proxy-docker.yaml
        declares, where the container ports rather than the published ones apply.
        """
        compact = active.deployment_profile == "compact"
        if active.proxy_placement == "host":
            host = active.reverse_proxy_backend_host
            app = f"{host}:{active.reverse_proxy_backend_port}"
            return app, "" if compact else f"{host}:{active.reverse_proxy_mcp_port}"
        from core.infrastructure.runtime_env import runtime_env

        project = str(runtime_env.get("FS_COMPOSE_PROJECT_NAME") or "flow-steward").strip()
        if compact:
            return f"{project}-compact-proxy:{active.runtime_http_port}", ""
        return f"{project}-app-proxy:8099", f"{project}-mcp-proxy:8100"

    def show(self, request: ConfigShowRequest | None = None) -> ConfigShowResult:
        del request
        active = self.read_active()
        assert active is not None
        pending = self.read_pending()
        diff: dict[str, dict[str, JsonValue]] = {}
        if pending is not None:
            # W3 (auditor): both sides as JSON. The active side was the raw attribute, and a
            # tuple (proxy_trusted_ips) is not a JSON value, so `config show` crashed while
            # such a change was pending.
            active_values = active.model_dump(mode="json")
            for field_name, pending_value in pending.model_dump(
                mode="json", exclude_none=True
            ).items():
                diff[field_name] = {
                    "active": active_values.get(field_name),
                    "pending": pending_value,
                }
        statuses = self.store.secret_statuses(active)
        return ConfigShowResult(
            active=active,
            pending=pending,
            pending_diff=diff,
            protected_setting_states=tuple(
                ConfigSecretState(
                    name=name,
                    state="configured" if configured else "missing",
                )
                for name, configured in sorted(statuses.items())
            ),
        )

    def set(self, patch: ConfigurationPatch) -> ConfigSetResult:
        """Atomically replace the pending typed patch without runtime effects."""
        if self.lifecycle_state is None:
            raise LifecycleError.dependency(
                code="configuration_lifecycle_unavailable",
                cause="The durable lifecycle state adapter is unavailable.",
                remediation=_MESSAGE_RETRY_FROM_THE_INSTALLED_FLOW_STEWARD_CLI_RUNTIME,
                step="runtime",
            )
        existing = self._resumable_apply_journal()
        if existing is not None:
            raise _configuration_journal_error(
                operation_id=existing.operation_id,
                cause="Pending configuration cannot change while an apply journal is unfinished.",
                recovery_command=existing.recovery_command,
            )
        operation_id = f"config-set-{uuid4().hex}"
        with self.lifecycle_state.operation_lock(operation_id, mutating=True):
            existing = self._resumable_apply_journal(diagnose_lock=False)
            if existing is not None:
                raise _configuration_journal_error(
                    operation_id=existing.operation_id,
                    cause="Pending configuration cannot change while an apply journal is unfinished.",
                    recovery_command=existing.recovery_command,
                )
            active = self.read_active()
            assert active is not None
            self._candidate(active, patch)
            self.store.write_pending(patch)
        return ConfigSetResult(pending=patch)

    stage_patch = set

    def validate(
        self, request: ConfigValidateRequest | None = None
    ) -> ConfigurationValidationResult:
        del request
        active = self.read_active()
        assert active is not None
        pending = self.read_pending()
        active_target = self.derive_target(active)
        issues = list(self._validate_one("active", active, managed_target=active_target))
        if pending is not None:
            issues.extend(
                self._validate_one(
                    "pending",
                    self._candidate(active, pending),
                    managed_target=active_target,
                )
            )
        return ConfigurationValidationResult(valid=not issues, issues=tuple(issues))

    def _validate_one(
        self,
        label: str,
        config: DeploymentConfig,
        *,
        managed_target: ComposeTarget,
    ) -> tuple[str, ...]:
        issues = [f"{label}: {issue}" for issue in self.validate_config(config).issues]
        if self.gateway is None:
            issues.append(f"{label}: configuration runtime adapter is unavailable")
            return tuple(issues)
        try:
            target, _path, environment = self._prepared_environment(config)
            self.gateway.validate_target(
                config,
                target,
                environment,
                managed_target=managed_target,
            )
        except Exception as exc:
            issues.append(f"{label}: {str(exc).strip() or type(exc).__name__}")
        return tuple(issues)

    def plan_apply(self, request: ConfigApplyRequest) -> dict[str, object]:
        del request
        active = self.read_active()
        assert active is not None
        pending = self.read_pending()
        if pending is None:
            raise LifecycleError.stable_failure(
                code="nothing_to_apply",
                cause="There is no pending configuration patch to apply.",
                remediation="Run flow-steward config set first.",
                step="configuration",
            )
        candidate = self._candidate(active, pending)
        validation = self.validate_config(candidate)
        if not validation.valid:
            raise LifecycleError.stable_failure(
                code="configuration_invalid",
                cause="The pending configuration is invalid: " + "; ".join(validation.issues),
                remediation="Correct the pending values before applying them.",
                step="validation",
            )
        return {
            "pending_fields": sorted(pending.model_dump(exclude_none=True)),
            "runtime_change": True,
            "compose_project": self.derive_target(candidate).project_name,
            "preservation": "required",
            "rollback": "exact previous configuration and runtime",
        }

    def validate_config(self, config: DeploymentConfig) -> ConfigurationValidationResult:
        issues: list[str] = []
        if not config.public_host.strip():
            issues.append("public_host must not be empty")
        elif not _valid_public_host(config.public_host):
            issues.append("public_host must be a strict DNS name or IP address")
        if config.file_storage == "external_s3" and not config.s3_endpoint.strip():
            issues.append("external_s3 requires a configured endpoint")
        if config.tls_mode == "provided":
            paths: dict[str, Path] = {}
            for label, raw_path in (
                ("certificate", config.certificate_path),
                ("private key", config.private_key_path),
            ):
                path = self.store.resolve_project_path(raw_path)
                if not path.is_file():
                    issues.append(f"provided TLS {label} path is unavailable: {raw_path}")
                else:
                    paths[label] = path
            if len(paths) == 2:
                issues.extend(
                    _provided_tls_issues(
                        config.public_host,
                        cert_path=paths["certificate"],
                        key_path=paths["private key"],
                    )
                )
        return ConfigurationValidationResult(valid=not issues, issues=tuple(issues))

    def derive_target(
        self,
        config: DeploymentConfig,
        *,
        identity_source: DeploymentConfig | None = None,
        project_name_override: str | None = None,
    ) -> ComposeTarget:
        development = config.environment == "development"
        compact = config.deployment_profile == "compact"
        if development:
            base_compose_file = "infra/docker/docker-compose.yaml"
        elif compact:
            base_compose_file = "infra/docker/docker-compose.compact.yaml"
        else:
            base_compose_file = "infra/docker/docker-compose.prod.yaml"
        compose_files = [base_compose_file]
        if compact:
            ingress_file = f"infra/docker/compact/ingress-{config.ingress_mode}.yaml"
            if config.ingress_mode == "external_proxy":
                ingress_file = (
                    f"infra/docker/compact/ingress-external_proxy-{config.proxy_placement}.yaml"
                )
            compose_files.append(ingress_file)
            if config.ingress_mode == "external_traefik" and config.traefik_http_entrypoint.strip():
                compose_files.append(
                    "infra/docker/compact/ingress-external_traefik-http-redirect.yaml"
                )
            if config.tls_mode == "external_resolver":
                compose_files.append("infra/docker/compact/tls-external-resolver.yaml")
            elif config.ingress_mode == "bundled_traefik":
                compose_files.append(
                    "infra/docker/compact/tls-bundled-acme.yaml"
                    if config.tls_mode == "acme"
                    else "infra/docker/compact/tls-bundled-files.yaml"
                )
        elif not development:
            if config.ingress_mode == "external_proxy":
                compose_files.append(
                    f"infra/docker/scalable/ingress-external_proxy-{config.proxy_placement}.yaml"
                )
            elif config.ingress_mode == "external_traefik":
                compose_files.append("infra/docker/scalable/ingress-external_traefik.yaml")
                if config.traefik_http_entrypoint.strip():
                    compose_files.append(
                        "infra/docker/scalable/ingress-external_traefik-http-redirect.yaml"
                    )
                if config.tls_mode == "external_resolver":
                    compose_files.append("infra/docker/scalable/tls-external-resolver.yaml")
            elif config.ingress_mode == "bundled_traefik" and config.tls_mode == "acme":
                compose_files.append("infra/docker/scalable/tls-bundled-acme.yaml")
        if compact and config.file_storage == "bundled":
            # Item 5, step 5: SeaweedFS beside the Compact runtime, on its own volumes.
            compose_files.append("infra/docker/compact/storage-bundled.yaml")
        if compact and config.data_placement == "host_directories":
            # A Compact runtime on the trees a Scalable installation created (item 5).
            compose_files.append("infra/docker/compact/data-host_directories.yaml")
            if config.file_storage == "local_fs":  # AC17-R169: otherwise not a host tree
                compose_files.append("infra/docker/compact/data-host_directories-artifacts.yaml")
        elif not compact and not development and config.data_placement == "compact_volume":
            # A Scalable installation on the trees a Compact one created (item 5).
            compose_files.append("infra/docker/scalable/data-compact_volume.yaml")
        if development and config.ingress_mode == "external_proxy":
            compose_files.append(
                ".flow-steward/installer.compose.override.yaml"
                if config.proxy_placement == "host"
                else "infra/docker/scalable/ingress-external_proxy-docker.yaml"
            )
        profiles: list[str] = []
        services = (
            ["rabbitmq-fs", "pg-fs", "compact-runtime"]
            if compact
            else [
                service
                for service in _BASE_SERVICES
                if service != "traefik" or config.ingress_mode == "bundled_traefik"
            ]
        )
        if compact and config.ingress_mode == "bundled_traefik":
            services.append("traefik")
        if not compact and not development and config.ingress_mode == "bundled_traefik":
            profiles.append("bundled-ingress")
        if config.file_storage == "bundled":
            profiles.append("storage-seaweedfs")
            services.append("seaweedfs")
        profiles.append("cli")
        services.append("fs-cli")
        if development:
            profiles.extend(("development", "test", "audit", "quality"))
            services.extend(
                (
                    "fs-frontend",
                    "mailpit",
                    "fs-test-runner",
                    "fs-audit",
                    "pg-audit",
                    "rabbitmq-audit",
                    "sonarqube",
                    "sonar-scanner",
                )
            )
        runtime_services = tuple(
            service
            for service in services
            if service not in {"mailpit", "sonarqube", "sonar-scanner"}
            and not (service == "traefik" and config.tls_mode == "reverse_proxy")
        )
        rebuild_services = (
            tuple(
                service
                for service in services
                if service
                in {
                    "pg-fs",
                    "fs-mcp",
                    "fs-app",
                    "fs-extension-installer",
                    "fs-worker",
                    "control-plane",
                    "fs-test-runner",
                    "fs-audit",
                }
            )
            if development
            else _production_preserved_services(compact)
        )
        try:
            project_name = str(project_name_override or "").strip() or (
                self.store.transition_project_name(identity_source)
                if identity_source is not None
                else self.store.project_name(config)
            )
        except ValueError as exc:
            raise LifecycleError.stable_failure(
                code="configuration_identity_invalid",
                cause="The installed Compose project identity is inconsistent.",
                remediation="Repair the installed environment and compose identity before applying configuration.",
                step="configuration",
            ) from exc
        return ComposeTarget(
            stack_environment=config.environment,
            file_storage=config.file_storage,
            deployment_profile=config.deployment_profile,
            runtime_http_port=config.runtime_http_port,
            worker_processes=config.worker_processes,
            env_file=".env" if development else ".env.prod",
            compose_files=tuple(compose_files),
            compose_profiles=tuple(profiles),
            required_services=tuple(services),
            runtime_services=runtime_services,
            rebuild_services=rebuild_services,
            project_name=project_name,
        )

    def compose_environment(
        self,
        config: DeploymentConfig,
        target: ComposeTarget,
    ) -> dict[str, str]:
        """Return the canonical non-secret Compose control-plane environment."""
        values = self._active_compose_values(config, target)
        values.update(
            {
                "FS_TLS_CERTIFICATE_PATH": str(
                    self.store.resolve_project_path(config.certificate_path).resolve()
                ),
                "FS_TLS_PRIVATE_KEY_PATH": str(
                    self.store.resolve_project_path(config.private_key_path).resolve()
                ),
            }
        )
        return values

    def write_environment(self, config: DeploymentConfig) -> Path:
        _target, path, managed = self._prepared_environment(config)
        self.store.write_runtime_environment(path, managed)
        return path

    def prepare_environment(
        self,
        config: DeploymentConfig,
    ) -> tuple[ComposeTarget, Path, dict[str, str]]:
        """Prepare candidate Compose/environment values without writing them."""
        return self._prepared_environment(config)

    def prepare_transition_environment(
        self,
        active: DeploymentConfig,
        candidate: DeploymentConfig,
        target_overlay: Mapping[str, str] | None = None,
    ) -> tuple[ComposeTarget, Path, dict[str, str]]:
        """Render a transition candidate from the active durable environment only."""
        return self._prepared_environment(
            candidate,
            source=active,
            environment_overlay=target_overlay,
        )

    def stage_environment(
        self,
        config: DeploymentConfig,
        prepared: tuple[ComposeTarget, Path, dict[str, str]],
    ) -> Path:
        """Write only the candidate environment; keep active selection unchanged."""
        del config
        _target, path, managed = prepared
        self.store.write_runtime_environment(path, managed)
        return path

    def stage_transition_environment(
        self,
        active: DeploymentConfig,
        candidate: DeploymentConfig,
        prepared: tuple[ComposeTarget, Path, dict[str, str]],
    ) -> Path:
        """Stage a candidate using protected source lines from the active environment."""
        del candidate
        _target, path, managed = prepared
        self.store.write_transition_runtime_environment(
            path,
            managed,
            source_path=self.store.env_path(active),
        )
        return path

    def transition_environment_matches(
        self,
        active: DeploymentConfig,
        candidate: DeploymentConfig,
        prepared: tuple[ComposeTarget, Path, dict[str, str]],
    ) -> bool:
        """Check that a staged target is the exact active-source rendering."""
        del candidate
        _target, path, managed = prepared
        return self.store.transition_runtime_environment_matches(
            path,
            managed,
            source_path=self.store.env_path(active),
            allow_installed_storage_credentials=True,
        )

    def mark_active(
        self,
        previous: DeploymentConfig,
        config: DeploymentConfig,
        prepared: tuple[ComposeTarget, Path, dict[str, str]],
    ) -> None:
        """Idempotently publish all canonical active files and a final revision marker."""
        target, path, managed = prepared
        compose_values = self._active_compose_values(config, target)
        revision = self.store.begin_active_publication(
            previous,
            config,
            target_env_path=path,
            compose_values=compose_values,
        )
        self.store.write_active(config)
        self.store.write_runtime_environment(path, managed)
        self.store.write_compose_environment(compose_values)
        self.store.commit_active_publication(
            config,
            revision=revision,
            target_env_path=path,
        )

    def active_publication_matches(
        self,
        config: DeploymentConfig,
        prepared: tuple[ComposeTarget, Path, dict[str, str]],
    ) -> bool:
        _target, path, _managed = prepared
        return self.store.active_publication_matches(config) and path == self.store.env_path(config)

    def write_active_configuration(
        self,
        config: DeploymentConfig,
        *,
        prepared: tuple[ComposeTarget, Path, dict[str, str]] | None = None,
    ) -> ComposeTarget:
        target, path, managed = prepared or self._prepared_environment(config)
        self.store.write_active(config)
        self.store.write_runtime_environment(path, managed)
        self.store.write_compose_environment(self.compose_environment(config, target))
        return target

    @staticmethod
    def _active_compose_values(
        config: DeploymentConfig,
        target: ComposeTarget,
    ) -> dict[str, str]:
        values = {
            "FS_STACK_ENVIRONMENT": config.environment,
            "FS_DEPLOYMENT_PROFILE": config.deployment_profile,
            "FS_INGRESS_MODE": config.ingress_mode,
            "FS_PUBLIC_HOST": config.public_host,
            "FS_FILE_STORAGE": config.file_storage,
            "FS_RUNTIME_HTTP_PORT": str(config.runtime_http_port),
            # AC17-R92: Compose reads the redirect entrypoint from HTTP_PORT; it is an
            # answer now, not a variable the operator has to know to export.
            "HTTP_PORT": str(config.redirect_http_port),
            "FS_PROXY_PLACEMENT": config.proxy_placement,
            "FS_PROXY_KIND": config.proxy_kind,
            "FS_PROXY_TRUSTED_IPS": ",".join(config.proxy_trusted_ips),
            "FS_TRAEFIK_NETWORK": config.traefik_network,
            "FS_TRAEFIK_HTTPS_ENTRYPOINT": config.traefik_https_entrypoint,
            "FS_TRAEFIK_HTTP_ENTRYPOINT": config.traefik_http_entrypoint,
            "FS_TRAEFIK_CERT_RESOLVER": config.traefik_cert_resolver,
            "FS_PROXY_NETWORK": config.proxy_network,
            "FS_REVERSE_PROXY_BACKEND_PORT": str(config.reverse_proxy_backend_port),
            "FS_REVERSE_PROXY_MCP_PORT": str(config.reverse_proxy_mcp_port),
            "FS_ACME_CONTACT": config.acme_contact,
            "FS_ACME_DIRECTORY_URL": config.acme_directory_url,
            "FS_TLS_CERTIFICATE_PATH": config.certificate_path,
            "FS_TLS_PRIVATE_KEY_PATH": config.private_key_path,
            "FS_EXTENSION_INSTALLER_ORIGIN": config.extension_installer_origin,
            "FS_ENV_FILE": target.env_file,
            "FS_COMPOSE_FILES": " ".join(target.compose_files),
            "FS_COMPOSE_PROFILES": " ".join(target.compose_profiles),
            "FS_COMPOSE_SERVICES": " ".join(target.required_services),
            "FS_REBUILD_SERVICES": " ".join(target.rebuild_services),
        }
        if config.deployment_profile == "compact":
            values["FS_WORKER_PROCESSES"] = str(config.worker_processes)
        else:
            values["FS_WORKER_REPLICAS"] = str(config.worker_replicas)
        return values

    def apply(
        self,
        request: ConfigApplyRequest | None = None,
        *,
        progress_sink: ProgressSink | None = None,
        technical_sink: TechnicalSink | None = None,
        cancellation: CancellationToken | None = None,
    ) -> ConfigApplyCommandResult:
        del request
        if self.lifecycle_state is None:
            raise LifecycleError.dependency(
                code="configuration_lifecycle_unavailable",
                cause="The durable lifecycle state adapter is unavailable.",
                remediation=_MESSAGE_RETRY_FROM_THE_INSTALLED_FLOW_STEWARD_CLI_RUNTIME,
                step="runtime",
            )
        return self._apply_lifecycle(
            progress_sink=progress_sink,
            technical_sink=technical_sink,
            cancellation=cancellation,
        )

    apply_pending = apply

    def _apply_lifecycle(
        self,
        *,
        progress_sink: ProgressSink | None,
        technical_sink: TechnicalSink | None,
        cancellation: CancellationToken | None,
    ) -> ConfigApplyCommandResult:
        if self.gateway is None:
            raise LifecycleError.dependency(
                code="configuration_runtime_unavailable",
                cause="The configuration runtime adapter is unavailable.",
                remediation=_MESSAGE_RETRY_FROM_THE_INSTALLED_FLOW_STEWARD_CLI_RUNTIME,
                step="runtime",
            )
        assert self.lifecycle_state is not None
        existing = self._resumable_apply_journal()
        before_manifest: Mapping[str, object] | None = None
        runtime_snapshot: Mapping[str, object] | None = None
        if existing is None:
            active = self.read_active()
            assert active is not None
            selected_pending = self.store.read_pending_with_revision()
            if selected_pending is None:
                raise LifecycleError.stable_failure(
                    code="nothing_to_apply",
                    cause="There is no pending configuration patch to apply.",
                    remediation="Run flow-steward config set first.",
                    step="configuration",
                )
            pending, pending_revision = selected_pending
            candidate = self._candidate(active, pending)
            operation_id = uuid4().hex
            pending_fields = sorted(pending.model_dump(mode="json", exclude_none=True))
        else:
            (
                active,
                candidate,
                operation_id,
                pending_fields,
                pending_revision,
                before_manifest,
                runtime_snapshot,
            ) = self._resume_apply_evidence(existing)
        validation = self.validate_config(candidate)
        if not validation.valid:
            raise LifecycleError.stable_failure(
                code="configuration_invalid",
                cause="The pending configuration is invalid: " + "; ".join(validation.issues),
                remediation="Correct the pending values before applying them.",
                step="validation",
            )
        previous_environment = self._prepared_environment(active)[2]
        prepared = self._prepared_environment(candidate)
        target = prepared[0]
        previous_target = self.derive_target(active)
        context = _ConfigurationOperationContext(
            operation_id=operation_id,
            service=self,
            previous=active,
            candidate=candidate,
            previous_target=previous_target,
            target=target,
            prepared=prepared,
            previous_environment=previous_environment,
            lifecycle_state=self.lifecycle_state,
            durable_completed_steps=existing.completed_steps if existing is not None else (),
            before_manifest=before_manifest,
            runtime_snapshot=runtime_snapshot,
            pending_revision=pending_revision,
        )
        gateway = _ConfigurationOperationGateway(
            adapter=self.gateway,
            context=context,
        )
        if existing is not None and existing.status is LifecycleOperationStatus.RECOVERY_REQUIRED:
            return self._recover_existing_apply(existing, gateway)
        definition = LifecycleOperationDefinition(
            operation_id=operation_id,
            kind=LifecycleOperationKind.CONFIG_APPLY,
            steps=_configuration_operation_steps(),
            parameters={
                "candidate": candidate.model_dump(mode="json"),
                "project_name": target.project_name,
                "pending_fields": pending_fields,
                "pending_revision": pending_revision,
            },
            previous_config={
                "configuration": active.model_dump(mode="json"),
                "pending_revision": pending_revision,
            },
            recovery_command=_MESSAGE_FLOW_STEWARD_CONFIG_APPLY,
        )
        operation = LifecycleOperationRunner(
            gateway=gateway,
            state=self.lifecycle_state,
        ).execute(
            definition,
            progress_sink=progress_sink,
            technical_sink=technical_sink,
            cancellation=cancellation,
        )
        return ConfigApplyCommandResult(
            active=candidate,
            operation_id=operation.operation_id,
            journal_path=operation.journal_path,
            log_path=operation.log_path,
            snapshot_path=operation.previous_config_path or "",
            preservation_verified=gateway.preservation_verified,
            runtime_restored=False,
        )

    def _resume_apply_evidence(
        self, existing: LifecycleOperationJournal
    ) -> tuple[
        DeploymentConfig,
        DeploymentConfig,
        str,
        list[str],
        str,
        Mapping[str, object] | None,
        Mapping[str, object] | None,
    ]:
        assert self.gateway is not None
        operation_id = existing.operation_id
        snapshot = self._load_apply_snapshot(existing)
        try:
            active = DeploymentConfig.model_validate(snapshot["configuration"])
            raw_candidate = existing.parameters.get("candidate")
            if not isinstance(raw_candidate, dict):
                raise ValueError("candidate configuration is absent")
            candidate = DeploymentConfig.model_validate(raw_candidate)
        except (TypeError, ValueError, ValidationError) as exc:
            raise _configuration_journal_error(
                operation_id=operation_id,
                cause=(
                    "The interrupted apply journal contains invalid configuration "
                    "recovery evidence."
                ),
                recovery_command=existing.recovery_command,
            ) from exc
        raw_pending_fields = existing.parameters.get("pending_fields")
        if not isinstance(raw_pending_fields, list) or not all(
            isinstance(item, str) for item in raw_pending_fields
        ):
            raise _configuration_journal_error(
                operation_id=operation_id,
                cause="The interrupted apply journal is missing its pending field inventory.",
                recovery_command=existing.recovery_command,
            )
        pending_fields = [str(item) for item in raw_pending_fields]
        raw_pending_revision = existing.parameters.get("pending_revision")
        if not isinstance(raw_pending_revision, str) or not raw_pending_revision:
            raise _configuration_journal_error(
                operation_id=operation_id,
                cause="The interrupted apply journal is missing its pending revision.",
                recovery_command=existing.recovery_command,
            )
        pending_revision = raw_pending_revision
        before_manifest, runtime_snapshot = self._resume_preservation_evidence(existing, snapshot)
        return (
            active,
            candidate,
            operation_id,
            pending_fields,
            pending_revision,
            before_manifest,
            runtime_snapshot,
        )

    def _resume_preservation_evidence(
        self, existing: LifecycleOperationJournal, snapshot: Mapping[str, object]
    ) -> tuple[Mapping[str, object] | None, Mapping[str, object] | None]:
        assert self.gateway is not None
        operation_id = existing.operation_id
        runtime_snapshot: Mapping[str, object] | None = None
        raw_runtime_snapshot = snapshot.get("runtime")
        if isinstance(raw_runtime_snapshot, dict):
            runtime_snapshot = raw_runtime_snapshot
        try:
            before_manifest = self.gateway.load_manifest(operation_id, "before")
        except (OSError, TypeError, ValueError) as exc:
            raise _configuration_journal_error(
                operation_id=operation_id,
                cause="The interrupted apply preservation evidence is unreadable.",
                recovery_command=existing.recovery_command,
            ) from exc
        if "capture_before" in existing.completed_steps and before_manifest is None:
            raise _configuration_journal_error(
                operation_id=operation_id,
                cause="The interrupted apply lacks its pre-change preservation manifest.",
                recovery_command=existing.recovery_command,
            )
        if "capture_before" in existing.completed_steps and (
            runtime_snapshot is None or not self.gateway.recovery_available(operation_id)
        ):
            raise _configuration_journal_error(
                operation_id=operation_id,
                cause="The interrupted apply lacks exact file/runtime rollback evidence.",
                recovery_command=existing.recovery_command,
            )
        return before_manifest, runtime_snapshot

    def _resumable_apply_journal(
        self,
        *,
        diagnose_lock: bool = True,
    ) -> LifecycleOperationJournal | None:
        assert self.lifecycle_state is not None
        diagnosed_operation_id: str | None = None
        if diagnose_lock:
            diagnosis = self.lifecycle_state.diagnose_active_lock()
            diagnosed_operation_id = diagnosis.operation_id
            if diagnosis.status is LifecycleLockStatus.ACTIVE:
                raise LifecycleError.conflict(
                    operation_id=diagnosis.operation_id,
                    cause=diagnosis.detail,
                )
        try:
            candidates = self.lifecycle_state.unfinished_journals()
        except (OSError, ValueError) as exc:
            raise _configuration_journal_error(
                operation_id=diagnosed_operation_id or "unknown-operation",
                cause="Lifecycle journals are unreadable and safe resume cannot be proven.",
                recovery_command=(
                    "operator: repair or quarantine unreadable lifecycle journals under "
                    ".flow-steward/operations"
                ),
            ) from exc
        if not candidates:
            return None
        if len(candidates) != 1:
            paths = ", ".join(
                sorted(
                    f".flow-steward/operations/{journal.operation_id}.json"
                    for journal in candidates
                )
            )
            raise _configuration_journal_error(
                operation_id=candidates[0].operation_id,
                cause="Multiple unfinished lifecycle journals require operator reconciliation.",
                recovery_command=(
                    f"operator: reconcile lifecycle journals {paths}; retain exactly one "
                    "unfinished journal"
                ),
            )
        journal = candidates[0]
        if journal.kind is not LifecycleOperationKind.CONFIG_APPLY:
            raise _configuration_journal_error(
                operation_id=journal.operation_id,
                cause="An unfinished lifecycle operation has a different action.",
                recovery_command=journal.recovery_command,
            )
        return journal

    def _load_apply_snapshot(self, journal: LifecycleOperationJournal) -> dict[str, object]:
        assert self.lifecycle_state is not None
        try:
            snapshot = self.lifecycle_state.load_previous_config(journal.operation_id)
        except (OSError, ValueError) as exc:
            raise _configuration_journal_error(
                operation_id=journal.operation_id,
                cause="Saved previous configuration evidence is unreadable.",
                recovery_command=journal.recovery_command,
            ) from exc
        if snapshot is None or not isinstance(snapshot.get("configuration"), dict):
            raise _configuration_journal_error(
                operation_id=journal.operation_id,
                cause="The interrupted apply lacks its exact previous configuration snapshot.",
                recovery_command=journal.recovery_command,
            )
        return snapshot

    def _recover_existing_apply(
        self,
        journal: LifecycleOperationJournal,
        gateway: _ConfigurationOperationGateway,
    ) -> ConfigApplyCommandResult:
        assert self.lifecycle_state is not None
        with self.lifecycle_state.operation_lock(journal.operation_id, mutating=True):
            log = self.lifecycle_state.open_log(journal.operation_id)
            try:
                gateway.recover(
                    output_sink=log.write,
                    heartbeat=lambda _detail: None,
                )
                recovered = journal.model_copy(
                    update={
                        "status": LifecycleOperationStatus.FAILED,
                        "current_step": None,
                        "failed_step": "recovery",
                        "last_error_code": "configuration_recovery_completed",
                        "retryable": False,
                        "log_path": str(log.path),
                    }
                )
                self.lifecycle_state.save_journal(recovered)
            except LifecycleError as exc:
                exc.operation_id = journal.operation_id
                exc.log_path = str(log.path)
                raise
            finally:
                log.close()
        return ConfigApplyCommandResult(
            active=gateway.context.previous,
            operation_id=journal.operation_id,
            journal_path=str(self.lifecycle_state.journal_path(journal.operation_id)),
            log_path=str(log.path),
            snapshot_path=journal.previous_config_path or "",
            preservation_verified=gateway.preservation_verified,
            runtime_restored=True,
        )

    def _prepared_environment(
        self,
        config: DeploymentConfig,
        *,
        source: DeploymentConfig | None = None,
        environment_overlay: Mapping[str, str] | None = None,
    ) -> tuple[ComposeTarget, Path, dict[str, str]]:
        target = self.derive_target(config, identity_source=source)
        path = self.store.env_path(config)
        source_config = source or config
        durable_reader = getattr(self.store, "read_durable_environment", None)
        existing = (
            durable_reader(source_config)
            if callable(durable_reader)
            else self.store.read_env_values(self.store.env_path(source_config))
        )
        if environment_overlay is not None:
            existing.update({str(name): str(value) for name, value in environment_overlay.items()})
        try:
            managed = self.store.build_environment(config, existing)
        except ValueError as exc:
            raise LifecycleError.stable_failure(
                code="configuration_durable_secrets_unavailable",
                cause="The installed durable secret configuration is incomplete.",
                remediation="Run ./install.sh to provision the missing durable secrets, then retry.",
                step="configuration",
            ) from exc
        public_http_port = str(existing.get("HTTP_PORT") or "").strip()
        if public_http_port:
            # re.ASCII is load-bearing: a bare \d matches every Unicode decimal digit for
            # str patterns, and int() parses those too, so "8\u066099" would pass the
            # pattern and then be read as 8099. The flag keeps this exactly equivalent to
            # the [0-9] class it replaces (Sonar python:S6353).
            if not re.fullmatch(r"[1-9]\d{0,4}", public_http_port, re.ASCII) or not (
                1 <= int(public_http_port) <= 65535
            ):
                raise LifecycleError.stable_failure(
                    code="configuration_public_http_port_invalid",
                    cause="The installed public HTTP port is invalid.",
                    remediation="Repair HTTP_PORT in the installed environment, then retry.",
                    step="configuration",
                    details={"field": "HTTP_PORT"},
                )
            managed["HTTP_PORT"] = public_http_port
        base_url = _public_base_url(config)
        managed.update(
            {
                "FS_PUBLIC_BASE_URL": base_url,
                "FS_PUBLIC_HOST": config.public_host,
                "FS_PUBLIC_BIND_HOST": _public_bind_host(config.public_host),
                "FS_DEPLOYMENT_PROFILE": config.deployment_profile,
                "FS_INGRESS_MODE": config.ingress_mode,
                "APP_PORT": str(config.public_port),
                "FS_AUTH_TRUSTED_ORIGINS": base_url,
                "FS_PROXY_PLACEMENT": config.proxy_placement,
                "FS_PROXY_KIND": config.proxy_kind,
                "FS_PROXY_TRUSTED_IPS": ",".join(config.proxy_trusted_ips),
                "FS_TRAEFIK_NETWORK": config.traefik_network,
                "FS_TRAEFIK_HTTPS_ENTRYPOINT": config.traefik_https_entrypoint,
                "FS_TRAEFIK_HTTP_ENTRYPOINT": config.traefik_http_entrypoint,
                "FS_TRAEFIK_CERT_RESOLVER": config.traefik_cert_resolver,
                "FS_PROXY_NETWORK": config.proxy_network,
                "FS_REVERSE_PROXY_BACKEND_PORT": str(config.reverse_proxy_backend_port),
                "FS_REVERSE_PROXY_MCP_PORT": str(config.reverse_proxy_mcp_port),
                "FS_ACME_CONTACT": config.acme_contact,
                "FS_ACME_DIRECTORY_URL": config.acme_directory_url,
                "FS_TLS_CERTIFICATE_PATH": str(
                    self.store.resolve_project_path(config.certificate_path).resolve()
                ),
                "FS_TLS_PRIVATE_KEY_PATH": str(
                    self.store.resolve_project_path(config.private_key_path).resolve()
                ),
                "FS_EXTENSION_INSTALLER_ORIGIN": config.extension_installer_origin,
            }
        )
        # AC17-R167: never the source profile's, which `existing` holds on a switch.
        managed.update(profile_owned_environment(config.deployment_profile))
        if config.deployment_profile == "compact" and config.data_placement == "host_directories":
            # AC17-R174: the Compact overlay binds Scalable's host trees and requires where
            # they are. The apply renders from these values alone (--env-file /dev/null).
            # The installer recorded them in the installed file; else Scalable's own
            # defaults.
            for name, default in _SCALABLE_HOST_TREES.items():
                managed[name] = str(existing.get(name) or managed.get(name) or default)
        if config.deployment_profile == "compact":
            managed.update(
                {
                    "FS_RUNTIME_HTTP_PORT": str(config.runtime_http_port),
                    "FS_WORKER_PROCESSES": str(config.worker_processes),
                }
            )
        else:
            # Review P2: read by fs-worker's `deploy.replicas`, so every `compose up` --
            # apply, restore, installer update -- keeps the configured worker count.
            managed["FS_WORKER_REPLICAS"] = str(config.worker_replicas)
        if config.environment == "production":
            candidate_state_dir = self.store.pending_path.parent.resolve()
            candidate_prod_env = path.resolve()
            if self.docker_host_project_root is not None:
                candidate_state_dir = (self.docker_host_project_root / ".flow-steward").resolve()
                candidate_prod_env = (self.docker_host_project_root / path.name).resolve()
            managed.update(
                {
                    "FS_CANDIDATE_STATE_DIR": str(candidate_state_dir),
                    "FS_CANDIDATE_PROD_ENV": str(candidate_prod_env),
                }
            )
        if config.file_storage == "external_s3":
            managed.update(
                {
                    "ARTIFACT_S3_ENDPOINT_URL": config.s3_endpoint,
                    "ARTIFACT_S3_BUCKET": config.s3_bucket,
                    "ARTIFACT_S3_REGION": config.s3_region,
                    "ARTIFACT_S3_USE_SSL": (
                        "true" if config.s3_endpoint.lower().startswith("https://") else "false"
                    ),
                }
            )
        return target, path, managed

    @staticmethod
    def _candidate(active: DeploymentConfig, patch: ConfigurationPatch) -> DeploymentConfig:
        values = active.model_dump(mode="json")
        changes = patch.model_dump(mode="json", exclude_none=True)
        if (
            changes.get("deployment_profile", values["deployment_profile"])
            != values["deployment_profile"]
        ):
            # The documented `config apply` switch copies the trees into the target
            # profile's own place, so they are re-derived from it -- unless the patch
            # names the placement, which only ./install.sh --deployment-profile writes
            # (item 5, step 4): it keeps the trees where they are.
            values.pop("data_placement", None)
        values.update(changes)
        return DeploymentConfig.model_validate(values)


def _public_base_url(config: DeploymentConfig) -> str:
    host = config.public_host
    if ":" in host and not host.startswith("["):
        host = f"[{host}]"
    default_port = config.public_port == 443
    return f"https://{host}{'' if default_port else f':{config.public_port}'}"


def _valid_public_host(value: str) -> bool:
    if value != value.strip() or any(
        character.isspace() or ord(character) < 32 or ord(character) == 127 for character in value
    ):
        return False
    try:
        ip_address(value)
        return True
    except ValueError:
        pass
    if len(value) > 253 or value.endswith("."):
        return False
    return all(
        re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?", label)
        for label in value.split(".")
    )


def _provided_tls_issues(
    public_host: str,
    *,
    cert_path: Path,
    key_path: Path,
) -> tuple[str, ...]:
    try:
        certificates = x509.load_pem_x509_certificates(cert_path.read_bytes())
        if not certificates:
            raise ValueError("certificate chain is empty")
        certificate = certificates[0]
        private_key = serialization.load_pem_private_key(
            key_path.read_bytes(),
            password=None,
        )
    except (OSError, TypeError, ValueError):
        return ("provided TLS certificate or private key is not valid unencrypted PEM",)
    certificate_public = certificate.public_key().public_bytes(
        serialization.Encoding.DER,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    private_public = private_key.public_key().public_bytes(
        serialization.Encoding.DER,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    issues: list[str] = []
    if certificate_public != private_public:
        issues.append("provided TLS certificate does not match the private key")
    now = datetime.now(UTC)
    if not (certificate.not_valid_before_utc <= now < certificate.not_valid_after_utc):
        issues.append("provided TLS certificate is not valid at the current time")
    for child, issuer in pairwise(certificates):
        if not (issuer.not_valid_before_utc <= now < issuer.not_valid_after_utc):
            issues.append("provided TLS certificate chain contains an expired issuer")
            break
        try:
            child.verify_directly_issued_by(issuer)
        except ValueError:
            issues.append("provided TLS certificate chain is not ordered or valid")
            break
    try:
        san = certificate.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    except x509.ExtensionNotFound:
        issues.append("provided TLS certificate has no subject alternative name")
    else:
        try:
            expected_ip = ip_address(public_host)
        except ValueError:
            dns_names = {name.casefold() for name in san.get_values_for_type(x509.DNSName)}
            if public_host.casefold() not in dns_names:
                issues.append("provided TLS certificate SAN does not include the public host")
        else:
            if expected_ip not in set(san.get_values_for_type(x509.IPAddress)):
                issues.append("provided TLS certificate SAN does not include the public IP")
    return tuple(issues)


class _ConfigurationOperationContext:
    def __init__(
        self,
        *,
        operation_id: str,
        service: ConfigurationService,
        previous: DeploymentConfig,
        candidate: DeploymentConfig,
        previous_target: ComposeTarget,
        target: ComposeTarget,
        prepared: tuple[ComposeTarget, Path, dict[str, str]],
        previous_environment: Mapping[str, str],
        lifecycle_state: LifecycleState,
        durable_completed_steps: tuple[str, ...],
        before_manifest: Mapping[str, object] | None,
        runtime_snapshot: Mapping[str, object] | None,
        pending_revision: str,
    ) -> None:
        self.operation_id = operation_id
        self.service = service
        self.previous = previous
        self.candidate = candidate
        self.previous_target = previous_target
        self.target = target
        self.prepared = prepared
        self.previous_environment = dict(previous_environment)
        self.lifecycle_state = lifecycle_state
        self.durable_completed_steps = frozenset(durable_completed_steps)
        self.before_manifest = before_manifest
        self.runtime_snapshot = runtime_snapshot
        self.pending_revision = pending_revision


class _ConfigurationOperationGateway:
    """Interpret durable config-apply steps through the injected technical adapter."""

    def __init__(
        self,
        *,
        adapter: ConfigurationApplyGateway,
        context: _ConfigurationOperationContext,
    ) -> None:
        self.adapter = adapter
        self.context = context
        self.after_manifest: Mapping[str, object] | None = None
        self.mutated = False
        self.preservation_verified = False
        # AC17-R167: the rollback writes into the operation log of the step it undoes.
        self._output_sink: TechnicalSink = _discard_line

    def postcondition_holds(
        self,
        _definition: LifecycleOperationDefinition,
        step: LifecycleOperationStep,
    ) -> bool:
        if step.step_id == "verify_pending_revision":
            return "verify_pending_revision" in self.context.durable_completed_steps
        if step.step_id == "capture_before":
            return bool(
                self.context.before_manifest is not None
                and self.context.runtime_snapshot is not None
                and self.adapter.recovery_available(self.context.operation_id)
            )
        if step.step_id == "render_configuration":
            return (
                "render_configuration" in self.context.durable_completed_steps
                and self.context.service.read_active() == self.context.candidate
            )
        if step.step_id == "change_runtime":
            completed = "change_runtime" in self.context.durable_completed_steps
            self.mutated = completed
            return completed
        if step.step_id == "verify_health":
            try:
                return self.adapter.healthy(self.context.candidate, self.context.target)
            except Exception:
                return False
        if step.step_id == "commit_pending":
            return (
                not self.context.service.store.pending_revision_matches(
                    self.context.pending_revision
                )
                and self.context.service.read_active() == self.context.candidate
            )
        return False

    def execute_step(
        self,
        definition: LifecycleOperationDefinition,
        step: LifecycleOperationStep,
        *,
        output_sink: TechnicalSink,
        heartbeat: HeartbeatSink,
        cancellation: CancellationToken,
    ) -> None:
        del heartbeat, cancellation
        self._output_sink = output_sink
        if step.step_id == "verify_pending_revision":
            self._execute_verify_pending_revision()
            return
        if step.step_id == "validate_target":
            self._execute_validate_target()
            return
        if step.step_id == "capture_before":
            self._execute_capture_before()
            return
        if step.step_id == "render_configuration":
            self._execute_render_configuration()
            return
        if step.step_id == "change_runtime":
            self._execute_change_runtime()
            return
        if step.step_id == "verify_health":
            self._execute_verify_health(output_sink)
            return
        if step.step_id == "capture_after":
            self._execute_capture_after()
            return
        if step.step_id == "verify_preservation":
            self._execute_verify_preservation(definition, step)
            return
        if step.step_id == "commit_pending":
            self._execute_commit_pending()
            return
        raise LifecycleError.internal(
            step=step.step_id,
            recovery_command=definition.recovery_command,
        )

    def _execute_verify_pending_revision(self) -> None:
        if not self.context.service.store.pending_revision_matches(self.context.pending_revision):
            raise LifecycleError.stable_failure(
                code="pending_configuration_changed",
                cause="The pending configuration changed before apply acquired the mutation lock.",
                remediation="Review the current pending diff and run config apply again.",
                step="pending_revision",
            )

    def _execute_validate_target(self) -> None:
        try:
            self.adapter.validate_target(
                self.context.candidate,
                self.context.target,
                self.context.prepared[2],
                managed_target=self.context.previous_target,
            )
        except Exception as exc:
            raise LifecycleError.stable_failure(
                code="configuration_invalid",
                cause="The pending configuration or rendered Compose target is invalid.",
                remediation="Run flow-steward config validate and correct the reported issue.",
                step="validate_target",
                details=_configuration_failure_details(exc),  # AC17-R174: say what, too
            ) from exc

    def _execute_capture_before(self) -> None:
        try:
            if self.context.runtime_snapshot is None:
                self.context.runtime_snapshot = self.adapter.capture_recovery(
                    self.context.previous_target,
                    self.context.target,
                    operation_id=self.context.operation_id,
                )
            if self.context.before_manifest is None:
                self.context.before_manifest = self.adapter.capture_manifest(
                    self.context.previous,
                    self.context.previous_target,
                    operation_id=self.context.operation_id,
                    stage="before",
                )
            self.adapter.validate_preservation_baseline(self.context.before_manifest)
            self.context.lifecycle_state.save_previous_config(
                self.context.operation_id,
                {
                    "configuration": self.context.previous.model_dump(mode="json"),
                    "pending_revision": self.context.pending_revision,
                    "runtime": dict(self.context.runtime_snapshot),
                },
            )
        except Exception as exc:
            failure = LifecycleError.stable_failure(
                code="configuration_preservation_capture_failed",
                cause="The pre-apply preservation manifest could not be captured.",
                remediation="Repair the reported observation before applying configuration.",
                step="capture_before",
            )
            raw_failed_fields = getattr(exc, "failed_fields", ())
            if isinstance(raw_failed_fields, (list, tuple)):
                failed_fields = sorted(
                    {
                        str(field)
                        for field in raw_failed_fields
                        if re.fullmatch(r"[a-z][a-z0-9_]{0,127}", str(field))
                    }
                )
                if failed_fields:
                    failure.details["failed_fields"] = failed_fields
            raise failure from exc
        self._refuse_unrecorded_worker_scale()

    def _refuse_unrecorded_worker_scale(self) -> None:
        """Refuse to apply over a worker count nobody recorded.

        Review P2: Scalable used to be scaled with a bare `--scale fs-worker=N`, and every
        lifecycle `compose up` returned fs-worker to its declared count -- so an apply of
        any unrelated change quietly took the extra workers away. The count is now
        configuration; a running count that matches neither the recorded one nor the one
        being applied is named here, before anything changes.
        """
        previous = self.context.previous
        if previous.deployment_profile != "scalable" or self.context.runtime_snapshot is None:
            return
        # The rollback snapshot as the adapter recorded it (stack_service owns the model
        # and imports this module, so it is read as the mapping it is persisted as).
        recorded_services = self.context.runtime_snapshot.get("services")
        running = next(
            (
                int(item.get("replicas") or 1)
                for item in (
                    recorded_services if isinstance(recorded_services, (list, tuple)) else ()
                )
                if isinstance(item, Mapping)
                and item.get("service") == "fs-worker"
                and item.get("topology") != "absent"
            ),
            None,
        )
        if running is None or running in {
            previous.worker_replicas,
            self.context.candidate.worker_replicas,
        }:
            return
        raise LifecycleError.stable_failure(
            code="worker_replicas_unrecorded",
            cause=(
                f"fs-worker runs {running} containers, but the configuration records "
                f"{previous.worker_replicas}. Applying would change the worker count "
                "without anyone asking for it."
            ),
            remediation=(
                "Record the running count with ./flow-steward config set --worker-replicas "
                f"{running}, or return to {previous.worker_replicas}, then apply again."
            ),
            step="capture_before",
        )

    def _execute_render_configuration(self) -> None:
        self.mutated = True
        try:
            self.context.service.write_active_configuration(
                self.context.candidate,
                prepared=self.context.prepared,
            )
            self.adapter.apply_artifacts(
                self.context.candidate,
                operation_id=self.context.operation_id,
            )
        except Exception as exc:
            self._recover_and_raise(exc)

    def _execute_change_runtime(self) -> None:
        self.mutated = True
        try:
            if self.context.runtime_snapshot is None:
                raise ValueError("Runtime recovery inventory is unavailable")
            self.adapter.activate(
                self.context.previous,
                self.context.candidate,
                self.context.previous_target,
                self.context.target,
                self.context.runtime_snapshot,
                source_environment=self.context.previous_environment,
            )
        except Exception as exc:
            self._recover_and_raise(exc)

    def _execute_verify_health(self, output_sink: TechnicalSink) -> None:
        try:
            healthy = self.adapter.healthy(self.context.candidate, self.context.target)
        except Exception as exc:
            self._keep_candidate_evidence(output_sink)
            self._recover_and_raise(exc)
        if not healthy:
            self._keep_candidate_evidence(output_sink)
            self._recover_and_raise(RuntimeError("target runtime did not become healthy"))

    def _keep_candidate_evidence(self, output_sink: TechnicalSink) -> None:
        """Copy what the candidate said into the operation log before rollback removes it.

        AC17-R152: the rollback recreates the previous containers, so the candidate's own
        log -- where the PermissionError that decided the apply was -- was gone, and the
        operation log held one line. Only a watcher running beside the apply saw it.
        Evidence must never replace the failure it explains, so its own errors are noted
        and swallowed.
        """
        try:
            self.adapter.candidate_diagnostics(
                self.context.candidate, self.context.target, output_sink
            )
        except Exception as exc:  # the primary failure is what the operator must get
            with suppress(Exception):
                output_sink(f"Candidate log could not be read: {type(exc).__name__}")

    def _execute_capture_after(self) -> None:
        try:
            self.after_manifest = self.adapter.capture_manifest(
                self.context.candidate,
                self.context.target,
                operation_id=self.context.operation_id,
                stage="after",
            )
        except Exception as exc:
            self._recover_and_raise(exc)

    def _execute_verify_preservation(
        self, definition: LifecycleOperationDefinition, step: LifecycleOperationStep
    ) -> None:
        if self.context.before_manifest is None or self.after_manifest is None:
            raise LifecycleError.internal(
                step=step.step_id,
                recovery_command=definition.recovery_command,
            )
        try:
            snapshot = self.context.runtime_snapshot
            if snapshot is None:
                raise ValueError("No runtime image evidence was recorded before config apply")
            if not self.adapter.runtime_images_match(self.context.target, snapshot):
                # AC17-R167 (live): a bare ValueError reached neither the log nor the
                # result, so which container changed, and to what, was nowhere.
                drift = self.adapter.runtime_image_drift(self.context.target, snapshot)
                raise _ImageDriftError(
                    "A retained container changed its image during config apply: "
                    + ("; ".join(drift) or "no change was seen on a second look")
                )
            self.adapter.compare_manifests(
                self.context.before_manifest,
                self.after_manifest,
                profile_transition=(
                    self.context.previous.deployment_profile
                    != self.context.candidate.deployment_profile
                ),
            )
        except Exception as exc:
            self._recover_and_raise(exc)
        self.preservation_verified = True

    def _execute_commit_pending(self) -> None:
        try:
            self.context.service.store.clear_pending_if_revision(self.context.pending_revision)
        except Exception as exc:
            self._recover_and_raise(exc)

    def _recover_and_raise(self, cause: Exception) -> NoReturn:
        failure_details = _configuration_failure_details(cause)
        restored = self._restore_previous()
        if restored:
            failure_cause = "The target configuration failed; the previous runtime was restored."
            diagnostic = ": ".join(
                str(failure_details[key])
                for key in ("failed_action", "failure_detail")
                if key in failure_details
            )
            if diagnostic:
                failure_cause = f"{failure_cause} Primary failure: {diagnostic}"
            raise LifecycleError.stable_failure(
                code="configuration_apply_failed",
                cause=failure_cause,
                remediation="Inspect the operation log, correct the pending patch, and retry.",
                step="recovery",
                details=failure_details,
            ) from cause
        failure = LifecycleError.recovery_required(
            code="configuration_recovery_required",
            cause="The target configuration failed and the previous runtime is not healthy.",
            remediation="Inspect the operation log and restore the previous runtime.",
            step="recovery",
            recovery_command=_MESSAGE_FLOW_STEWARD_CONFIG_APPLY,
        )
        failure.details.update(failure_details)
        raise failure from cause

    def _restore_previous(self) -> bool:
        """Restore the previous runtime; every stage says in the operation log how it went.

        AC17-R167: a failed profile switch logged only "the previous runtime was
        restored" -- what was restored, and how that was verified, was nowhere, and the
        restored runtime answered 502 until the next ./install.sh.
        """
        if not self.mutated or self.context.runtime_snapshot is None:
            return False
        say = self._output_sink
        say("Rollback: " + _rollback_plan_words(self.context.runtime_snapshot))
        try:
            if not self.adapter.restore_recovery(
                self.context.previous_target,
                operation_id=self.context.operation_id,
                snapshot=self.context.runtime_snapshot,
                output_sink=say,
            ):
                say("Rollback: the previous containers could not be restored exactly.")
                return False
            say("Rollback: the previous containers are back; waiting until they are ready.")
            if not self.adapter.recovery_healthy(
                self.context.previous,
                self.context.previous_target,
                self.context.runtime_snapshot,
            ):
                say("Rollback: the restored primary service is not running or not healthy.")
                return False
            say("Rollback: the previous runtime is ready.")
            if self.context.before_manifest is None:
                say("Rollback: no pre-apply preservation evidence to compare with.")
                return False
            recovered = self.adapter.capture_manifest(
                self.context.previous,
                self.context.previous_target,
                operation_id=self.context.operation_id,
                stage="after",
            )
            self.adapter.compare_manifests(
                self.context.before_manifest,
                recovered,
                profile_transition=(
                    self.context.previous.deployment_profile
                    != self.context.candidate.deployment_profile
                ),
            )
            say("Rollback: verified; the data is as it was before the apply.")
            return True
        except Exception as exc:
            with suppress(Exception):
                say(f"Rollback failed: {type(exc).__name__}: {redact_installer_text(str(exc))}")
            return False

    def recover(
        self,
        *,
        output_sink: TechnicalSink,
        heartbeat: HeartbeatSink,
    ) -> None:
        del heartbeat
        self._output_sink = output_sink
        self.mutated = True
        if not self._restore_previous():
            raise LifecycleError.recovery_required(
                code="configuration_recovery_required",
                cause="Exact previous configuration and runtime recovery was not verified.",
                remediation="Inspect the operation log and restore the previous runtime.",
                step="recovery",
                recovery_command=_MESSAGE_FLOW_STEWARD_CONFIG_APPLY,
            )
        self.preservation_verified = True


class _ImageDriftError(ValueError):
    """Named for the failure details: which container changed, and to what."""

    action = "image_drift"

    def __init__(self, detail: str) -> None:
        super().__init__(detail)
        self.detail = detail


def _discard_line(_line: str) -> None:
    return None


def _rollback_plan_words(snapshot: Mapping[str, object]) -> str:
    """What the rollback restores: each service, its recorded state and exact image."""
    services = snapshot.get("services")
    selected = snapshot.get("selected_services")
    parts: list[str] = []
    if isinstance(services, list) and isinstance(selected, list):
        for item in services:
            if isinstance(item, Mapping) and item.get("service") in selected:
                image = str(item.get("image_id") or "-")[:19]
                parts.append(f"{item.get('service')} {item.get('topology')} {image}")
    return "restoring " + (", ".join(parts) or "no recorded services") + "."


def _configuration_operation_steps() -> tuple[LifecycleOperationStep, ...]:
    return tuple(
        LifecycleOperationStep(step_id=step_id, label=label)
        for step_id, label in (
            ("verify_pending_revision", "Verify the selected pending configuration revision"),
            ("validate_target", "Validate configuration and Compose rendering"),
            ("capture_before", "Capture previous configuration and preservation state"),
            ("render_configuration", "Render active configuration and Compose environment"),
            ("change_runtime", "Apply the selected runtime configuration"),
            ("verify_health", "Verify runtime health"),
            ("capture_after", "Capture post-apply preservation state"),
            ("verify_preservation", "Verify preserved durable state"),
            ("commit_pending", "Commit the pending configuration"),
        )
    )


def _configuration_journal_error(
    *,
    operation_id: str,
    cause: str,
    recovery_command: str,
) -> LifecycleError:
    failure = LifecycleError.recovery_required(
        code="configuration_recovery_required",
        cause=cause,
        remediation=f"Inspect the lifecycle journal, then run exactly: {recovery_command}",
        step="recovery",
        recovery_command=recovery_command,
    )
    failure.operation_id = operation_id
    return failure
