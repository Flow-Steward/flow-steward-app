"""Safe environment transitions with explicit storage availability decisions."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Callable, Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Literal, NoReturn, Protocol, cast
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field, model_validator

from core.application.lifecycle.backup_service import (
    BackupCreateRequest,
    BackupResult,
    BackupService,
    BackupVerificationStatus,
)
from core.application.lifecycle.contracts import (
    CancellationToken,
    ComposeTarget,
    DeploymentConfig,
    LifecycleLockStatus,
    LifecycleOperationDefinition,
    LifecycleOperationJournal,
    LifecycleOperationKind,
    LifecycleOperationStatus,
    LifecycleOperationStep,
)
from core.application.lifecycle.errors import LifecycleError
from core.application.lifecycle.operation_service import LifecycleOperationRunner
from core.application.lifecycle.ports import (
    HeartbeatSink,
    LifecycleState,
    ProgressSink,
    TechnicalSink,
)
from core.application.lifecycle.stack_service import StackGatewayError
from core.application.management.command_specs.contracts import ExitCode, OperationStepStatus

DevelopmentTool = Literal["test_runner", "audit_tools", "sonarqube"]
ArtifactDecision = Literal["already_copied", "accept_unavailable"]
_COMPLETE_DEVELOPMENT_TOOLS: tuple[DevelopmentTool, ...] = (
    "test_runner",
    "audit_tools",
    "sonarqube",
)


class _ClosedModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class EnvironmentShowRequest(_ClosedModel):
    pass


class EnvironmentSwitchRequest(_ClosedModel):
    target: Literal["development", "production"]
    development_tools: tuple[DevelopmentTool, ...] = ()
    file_storage: Literal["keep", "bundled", "external_s3"] = "keep"
    s3_endpoint: str = ""
    s3_bucket: str = ""
    s3_region: str = ""
    s3_credentials_file: str = ""
    allow_insecure_s3_http: bool = False
    artifact_decision: ArtifactDecision | None = None

    @model_validator(mode="after")
    def validate_conditional_inputs(self) -> EnvironmentSwitchRequest:
        if self.target == "production" and self.development_tools:
            raise ValueError("Production cannot enable development tools")
        if len(self.development_tools) != len(set(self.development_tools)):
            raise ValueError("Development tools must be unique")
        if self.file_storage == "external_s3":
            missing = [
                name
                for name in (
                    "s3_endpoint",
                    "s3_bucket",
                    "s3_region",
                    "s3_credentials_file",
                )
                if not str(getattr(self, name)).strip()
            ]
            if missing:
                raise ValueError("external_s3 requires: " + ", ".join(missing))
        elif any(
            (
                self.s3_endpoint,
                self.s3_bucket,
                self.s3_region,
                self.s3_credentials_file,
                self.allow_insecure_s3_http,
            )
        ):
            raise ValueError("S3 inputs require file_storage=external_s3")
        return self


class StorageInventory(_ClosedModel):
    backend: Literal["local_fs", "bundled", "external_s3"]
    approximate_count: int | None = Field(default=None, ge=0)
    approximate_size_bytes: int | None = Field(default=None, ge=0)
    source_identity: str = Field(min_length=1)
    completeness: Literal["complete", "partial", "unknown"]

    @model_validator(mode="after")
    def validate_completeness(self) -> StorageInventory:
        if self.completeness == "unknown":
            if self.approximate_count is not None or self.approximate_size_bytes is not None:
                raise ValueError("Unknown inventory must not synthesize count or size")
        elif self.approximate_count is None or self.approximate_size_bytes is None:
            raise ValueError("Known inventory requires approximate count and size")
        return self


class EnvironmentResult(_ClosedModel):
    status: Literal["active", "already_active", "recovered"] = "active"
    active: DeploymentConfig
    active_environment: Literal["development", "production"]
    source_environment: Literal["development", "production"] | None = None
    source_release: str
    target_release: str
    operation_id: str | None = None
    journal_path: str | None = None
    log_path: str | None = None
    backup_path: str | None = None
    storage_inventory: StorageInventory | None = None
    artifact_decision: ArtifactDecision | None = None
    target_storage_identity: str | None = None
    preservation_verified: bool = False
    runtime_restored: bool = False
    retained_resources: tuple[str, ...] = ()


class EnvironmentConfiguration(Protocol):
    def read_active(self) -> DeploymentConfig: ...

    def derive_target(self, config: DeploymentConfig) -> ComposeTarget: ...

    def prepare_transition_environment(
        self,
        active: DeploymentConfig,
        candidate: DeploymentConfig,
        target_overlay: Mapping[str, str] | None = None,
    ) -> tuple[ComposeTarget, Path, dict[str, str]]: ...

    def stage_transition_environment(
        self,
        active: DeploymentConfig,
        candidate: DeploymentConfig,
        prepared: tuple[ComposeTarget, Path, dict[str, str]],
    ) -> Path: ...

    def transition_environment_matches(
        self,
        active: DeploymentConfig,
        candidate: DeploymentConfig,
        prepared: tuple[ComposeTarget, Path, dict[str, str]],
    ) -> bool: ...

    def mark_active(
        self,
        previous: DeploymentConfig,
        config: DeploymentConfig,
        prepared: tuple[ComposeTarget, Path, dict[str, str]],
    ) -> None: ...

    def active_publication_matches(
        self,
        config: DeploymentConfig,
        prepared: tuple[ComposeTarget, Path, dict[str, str]],
    ) -> bool: ...


class JobQuiescence(Protocol):
    def reconcile_pause(self, unfinished_operation_ids: tuple[str, ...]) -> object | None: ...

    def stop_accepting(self, operation_id: str) -> object: ...

    def pause_owned(self, operation_id: str) -> bool: ...

    def wait_for_idle(
        self,
        *,
        cancellation: CancellationToken,
        heartbeat: HeartbeatSink,
    ) -> None: ...

    def resume_accepting(self, operation_id: str) -> bool: ...


class EnvironmentStorage(Protocol):
    def target_identity(self, config: DeploymentConfig) -> str: ...

    def candidate_environment(
        self,
        config: DeploymentConfig,
        environment: Mapping[str, str],
    ) -> dict[str, str]: ...

    def provision_credentials(self, config: DeploymentConfig) -> Mapping[str, object]: ...

    def provisioning_matches(self, config: DeploymentConfig) -> bool: ...

    def inventory(self, config: DeploymentConfig) -> StorageInventory: ...

    def probe_write(
        self,
        config: DeploymentConfig,
        environment: Mapping[str, str],
    ) -> None: ...

    def install_credentials(self, config: DeploymentConfig, path: Path) -> None: ...

    def credentials_match(self, config: DeploymentConfig, path: Path) -> bool: ...

    def credential_evidence(
        self,
        config: DeploymentConfig,
        path: Path,
    ) -> Mapping[str, object]: ...


class EnvironmentRuntime(Protocol):
    def prepare_target_images(
        self,
        config: DeploymentConfig,
        target: ComposeTarget,
        environment: Mapping[str, str],
    ) -> None: ...

    def validate_target(
        self,
        config: DeploymentConfig,
        target: ComposeTarget,
        environment: Mapping[str, str],
        *,
        managed_target: ComposeTarget,
    ) -> None: ...

    def capture_recovery(
        self,
        previous_target: ComposeTarget,
        candidate_target: ComposeTarget,
        *,
        operation_id: str,
    ) -> Mapping[str, object]: ...

    def recovery_available(self, operation_id: str) -> bool: ...

    def capture_manifest(
        self,
        config: DeploymentConfig,
        target: ComposeTarget,
        *,
        operation_id: str,
        stage: Literal["before", "after"],
    ) -> Mapping[str, object]: ...

    def load_manifest(
        self,
        operation_id: str,
        stage: Literal["before", "after"],
    ) -> Mapping[str, object] | None: ...

    def validate_preservation_baseline(self, manifest: Mapping[str, object]) -> None: ...

    def apply_artifacts(self, config: DeploymentConfig, *, operation_id: str) -> None: ...

    def artifacts_match(self, config: DeploymentConfig) -> bool: ...

    def activate(
        self,
        previous: DeploymentConfig,
        config: DeploymentConfig,
        previous_target: ComposeTarget,
        target: ComposeTarget,
        runtime_snapshot: Mapping[str, object],
    ) -> None: ...

    def healthy(self, config: DeploymentConfig, target: ComposeTarget) -> bool: ...

    def runtime_release(self, config: DeploymentConfig, target: ComposeTarget) -> str: ...

    def compare_environment_manifests(
        self,
        before: Mapping[str, object],
        after: Mapping[str, object],
    ) -> None: ...

    def restore_recovery(
        self,
        target: ComposeTarget,
        *,
        operation_id: str,
        snapshot: Mapping[str, object],
    ) -> bool: ...


class EnvironmentService:
    """Own the environment/storage transition policy and its durable gates."""

    def __init__(
        self,
        *,
        configuration: EnvironmentConfiguration,
        jobs: JobQuiescence,
        backup: BackupService,
        storage: EnvironmentStorage,
        runtime: EnvironmentRuntime,
        lifecycle_state: LifecycleState,
        release_provider: Callable[[], str],
    ) -> None:
        self.configuration = configuration
        self.jobs = jobs
        self.backup = backup
        self.storage = storage
        self.runtime = runtime
        self.lifecycle_state = lifecycle_state
        self.release_provider = release_provider

    def show(self, request: EnvironmentShowRequest) -> EnvironmentResult:
        del request
        active = self.configuration.read_active()
        target = self.configuration.derive_target(active)
        release = self._release()
        return EnvironmentResult(
            active=active,
            active_environment=active.environment,
            source_release=release,
            target_release=release,
            target_storage_identity=self.storage.target_identity(active),
            retained_resources=_retained_resources(active, target),
        )

    def plan_switch(self, request: EnvironmentSwitchRequest) -> dict[str, object]:
        active = self.configuration.read_active()
        candidate = _candidate(active, request)
        target = self.configuration.derive_target(candidate)
        release = self._release()
        source_identity = self.storage.target_identity(active)
        target_identity = self.storage.target_identity(candidate)
        inventory = self.storage.inventory(active) if target_identity != source_identity else None
        return {
            "transition": f"{active.environment} -> {candidate.environment}",
            "release": f"{release} (unchanged)",
            "development_tools": list(candidate.development_tools),
            "long_running_services": list(target.runtime_services),
            "on_demand_services": [
                service
                for service in target.required_services
                if service not in target.runtime_services
            ],
            "storage_decision": request.file_storage,
            "target_storage_identity": target_identity,
            "source_storage_inventory": (
                inventory.model_dump(mode="json") if inventory is not None else None
            ),
            "artifact_decision_required": (
                _storage_decision_required(inventory) if inventory is not None else False
            ),
            "backup_gate": "required before config/runtime mutation",
            "preserve": [
                "Compose project and durable volume identities",
                "PostgreSQL data, Knowledge Base, users, and secret references",
                "old storage configuration, bundled volume, and artifact rows",
            ],
            "rollback": "exact previous configuration and runtime",
        }

    def switch(
        self,
        request: EnvironmentSwitchRequest,
        *,
        progress_sink: ProgressSink | None = None,
        technical_sink: TechnicalSink | None = None,
        cancellation: CancellationToken | None = None,
    ) -> EnvironmentResult:
        active = self.configuration.read_active()
        active_target = self.configuration.derive_target(active)
        existing = self._resumable_journal()
        self.jobs.reconcile_pause((existing.operation_id,) if existing is not None else ())
        if request.target == active.environment and existing is not None:
            try:
                return self._recover_same_environment(
                    journal=existing,
                    active=active,
                    active_target=active_target,
                )
            finally:
                self.jobs.resume_accepting(existing.operation_id)
        try:
            source_release = self.runtime.runtime_release(active, active_target)
        except (OSError, RuntimeError, ValueError) as exc:
            raise LifecycleError.dependency(
                code="environment_release_unavailable",
                cause="The active runtime release identity could not be inspected.",
                remediation="Repair the active runtime before switching environment.",
                step="inspect",
            ) from exc
        if not source_release:
            raise LifecycleError.dependency(
                code="environment_release_unavailable",
                cause="The active runtime release identity is unavailable.",
                remediation="Repair the active runtime before switching environment.",
                step="inspect",
            )
        if request.target == active.environment:
            return EnvironmentResult(
                status="already_active",
                active=active,
                active_environment=active.environment,
                source_release=source_release,
                target_release=source_release,
                target_storage_identity=self.storage.target_identity(active),
                retained_resources=_retained_resources(active, active_target),
            )
        candidate = _candidate(active, request)
        source_storage_identity = self.storage.target_identity(active)
        target_identity = self.storage.target_identity(candidate)
        storage_changed = target_identity != source_storage_identity
        environment = self.storage.candidate_environment(candidate, {}) if storage_changed else {}
        prepared = self.configuration.prepare_transition_environment(
            active,
            candidate,
            environment,
        )
        target = prepared[0]
        environment = prepared[2]
        if storage_changed and request.artifact_decision is None:
            preflight_inventory = self.storage.inventory(active)
            if _storage_decision_required(preflight_inventory):
                raise _artifact_decision_required(preflight_inventory)
        operation_id = existing.operation_id if existing is not None else uuid4().hex
        context = _EnvironmentContext(
            operation_id=operation_id,
            request=request,
            previous=active,
            candidate=candidate,
            previous_target=active_target,
            target=target,
            prepared=prepared,
            source_release=source_release,
            target_storage_identity=target_identity,
            source_storage_identity=source_storage_identity,
            storage_changed=storage_changed,
            probe_target_storage=(storage_changed or candidate.file_storage == "external_s3"),
            durable_completed_steps=(existing.completed_steps if existing is not None else ()),
            durable_step_outputs=(existing.step_outputs if existing is not None else {}),
        )
        if existing is not None:
            self._load_resume_evidence(existing, context)
        gateway = _EnvironmentOperationGateway(service=self, context=context)
        definition = LifecycleOperationDefinition(
            operation_id=operation_id,
            kind=LifecycleOperationKind.ENVIRONMENT_SWITCH,
            steps=_environment_steps(
                storage_changed,
                context.probe_target_storage,
                candidate.environment == "production" and candidate.file_storage == "bundled",
            ),
            parameters={
                "source_environment": active.environment,
                "target_environment": candidate.environment,
                "source_release": source_release,
                "source_storage_identity": source_storage_identity,
                "target_storage_identity": target_identity,
                "artifact_decision": request.artifact_decision,
            },
            previous_config={"configuration": active.model_dump(mode="json")},
            recovery_command=(f"./flow-steward environment switch {active.environment} --confirm"),
        )
        operation = LifecycleOperationRunner(
            gateway=gateway,
            state=self.lifecycle_state,
        ).execute(
            definition,
            progress_sink=progress_sink,
            technical_sink=technical_sink,
            cancellation=cancellation,
        )
        return EnvironmentResult(
            active=candidate,
            active_environment=candidate.environment,
            source_environment=active.environment,
            source_release=source_release,
            target_release=gateway.target_release,
            operation_id=operation.operation_id,
            journal_path=operation.journal_path,
            log_path=operation.log_path,
            backup_path=gateway.backup_result.path if gateway.backup_result else None,
            storage_inventory=gateway.storage_inventory,
            artifact_decision=request.artifact_decision,
            target_storage_identity=target_identity,
            preservation_verified=gateway.preservation_verified,
            retained_resources=_retained_resources(active, target),
        )

    def _recover_same_environment(
        self,
        *,
        journal: LifecycleOperationJournal,
        active: DeploymentConfig,
        active_target: ComposeTarget,
    ) -> EnvironmentResult:
        source_environment = str(journal.parameters.get("source_environment") or "")
        target_environment = str(journal.parameters.get("target_environment") or "")
        source_release = str(journal.parameters.get("source_release") or "")
        if target_environment == active.environment and source_release:
            return self._resume_active_target_forward(
                journal=journal,
                active=active,
                active_target=active_target,
                source_environment=source_environment,
                source_release=source_release,
            )
        if source_environment != active.environment or not source_release:
            raise _environment_recovery_error(
                operation_id=journal.operation_id,
                cause="The unfinished environment switch does not match the active source.",
            )
        try:
            snapshot = self.lifecycle_state.load_previous_config(journal.operation_id)
            before = self.runtime.load_manifest(journal.operation_id, "before")
        except (OSError, ValueError) as exc:
            raise _environment_recovery_error(
                operation_id=journal.operation_id,
                cause="Environment rollback evidence is unreadable.",
            ) from exc
        runtime_snapshot = snapshot.get("runtime") if isinstance(snapshot, dict) else None
        if not isinstance(runtime_snapshot, dict) or before is None:
            raise _environment_recovery_error(
                operation_id=journal.operation_id,
                cause="Exact rollback evidence is unavailable.",
            )
        try:
            restored = self.runtime.restore_recovery(
                active_target,
                operation_id=journal.operation_id,
                snapshot=runtime_snapshot,
            )
            if not restored or not self.runtime.healthy(active, active_target):
                raise RuntimeError("previous runtime recovery was not verified")
            release = self.runtime.runtime_release(active, active_target)
            if release != source_release:
                raise RuntimeError("recovered runtime release differs from source")
            recovered = self.runtime.capture_manifest(
                active,
                active_target,
                operation_id=journal.operation_id,
                stage="after",
            )
            self.runtime.compare_environment_manifests(before, recovered)
        except (OSError, RuntimeError, ValueError) as exc:
            raise _environment_recovery_error(
                operation_id=journal.operation_id,
                cause="The exact previous runtime could not be reconciled.",
            ) from exc
        completed = self._completed_recovery_journal(journal)
        self.lifecycle_state.save_journal(completed)
        backup = self.backup.find_verified(journal.operation_id)
        return EnvironmentResult(
            status="recovered",
            active=active,
            active_environment=active.environment,
            source_environment=active.environment,
            source_release=source_release,
            target_release=source_release,
            operation_id=journal.operation_id,
            journal_path=str(self.lifecycle_state.journal_path(journal.operation_id)),
            log_path=journal.log_path,
            backup_path=backup.path if backup is not None else None,
            target_storage_identity=self.storage.target_identity(active),
            preservation_verified=True,
            runtime_restored=True,
            retained_resources=_retained_resources(active, active_target),
        )

    def _resume_active_target_forward(
        self,
        *,
        journal: LifecycleOperationJournal,
        active: DeploymentConfig,
        active_target: ComposeTarget,
        source_environment: str,
        source_release: str,
    ) -> EnvironmentResult:
        reached_publish = (
            journal.current_step in {"mark_active", "resume_jobs"}
            or "mark_active" in journal.completed_steps
        )
        if not reached_publish:
            raise _environment_recovery_error(
                operation_id=journal.operation_id,
                cause="The active target does not match the unfinished journal boundary.",
            )
        try:
            before = self.runtime.load_manifest(journal.operation_id, "before")
            if before is None or not self.runtime.healthy(active, active_target):
                raise RuntimeError("active target recovery evidence is unavailable")
            release = self.runtime.runtime_release(active, active_target)
            if release != source_release:
                raise RuntimeError("active target release differs from source")
            after = self.runtime.load_manifest(journal.operation_id, "after")
            if after is None:
                after = self.runtime.capture_manifest(
                    active,
                    active_target,
                    operation_id=journal.operation_id,
                    stage="after",
                )
            self.runtime.compare_environment_manifests(before, after)
            self.jobs.resume_accepting(journal.operation_id)
        except (OSError, RuntimeError, ValueError) as exc:
            raise _environment_recovery_error(
                operation_id=journal.operation_id,
                cause="The published target could not be safely finalized.",
            ) from exc
        self.lifecycle_state.save_journal(self._completed_recovery_journal(journal))
        backup = self.backup.find_verified(journal.operation_id)
        return EnvironmentResult(
            status="recovered",
            active=active,
            active_environment=active.environment,
            source_environment=cast(
                Literal["development", "production"] | None,
                source_environment if source_environment in {"development", "production"} else None,
            ),
            source_release=source_release,
            target_release=source_release,
            operation_id=journal.operation_id,
            journal_path=str(self.lifecycle_state.journal_path(journal.operation_id)),
            log_path=journal.log_path,
            backup_path=backup.path if backup is not None else None,
            target_storage_identity=self.storage.target_identity(active),
            preservation_verified=True,
            runtime_restored=False,
            retained_resources=_retained_resources(active, active_target),
        )

    @staticmethod
    def _completed_recovery_journal(
        journal: LifecycleOperationJournal,
    ) -> LifecycleOperationJournal:
        completed_ids = tuple(step.step_id for step in journal.steps)
        return journal.model_copy(
            update={
                "status": LifecycleOperationStatus.COMPLETED,
                "steps": tuple(
                    step.model_copy(update={"status": OperationStepStatus.SUCCEEDED})
                    for step in journal.steps
                ),
                "completed_steps": completed_ids,
                "current_step": None,
                "failed_step": None,
                "last_error_code": None,
                "retryable": False,
                "updated_at": datetime.now(UTC),
            }
        )

    def _release(self) -> str:
        release = str(self.release_provider() or "").strip()
        if not release:
            raise LifecycleError.dependency(
                code="environment_release_unavailable",
                cause="The installed Flow Steward release identity is unavailable.",
                remediation="Repair the installed release metadata before switching environment.",
                step="inspect",
            )
        return release

    def _resumable_journal(self) -> LifecycleOperationJournal | None:
        diagnosis = self.lifecycle_state.diagnose_active_lock()
        if diagnosis.status is LifecycleLockStatus.ACTIVE:
            raise LifecycleError.conflict(
                operation_id=diagnosis.operation_id,
                cause=diagnosis.detail,
            )
        try:
            journals = self.lifecycle_state.unfinished_journals()
        except (OSError, ValueError) as exc:
            raise _environment_recovery_error(
                operation_id=diagnosis.operation_id or "unknown-operation",
                cause="Lifecycle journals are unreadable and safe resume cannot be proven.",
            ) from exc
        if not journals:
            return None
        if len(journals) != 1 or journals[0].kind is not LifecycleOperationKind.ENVIRONMENT_SWITCH:
            raise _environment_recovery_error(
                operation_id=journals[0].operation_id,
                cause="An unfinished lifecycle operation requires operator reconciliation.",
            )
        return journals[0]

    def _load_resume_evidence(
        self,
        journal: LifecycleOperationJournal,
        context: _EnvironmentContext,
    ) -> None:
        try:
            snapshot = self.lifecycle_state.load_previous_config(journal.operation_id)
            manifest = self.runtime.load_manifest(journal.operation_id, "before")
        except (OSError, ValueError) as exc:
            raise _environment_recovery_error(
                operation_id=journal.operation_id,
                cause="Environment rollback evidence is unreadable.",
            ) from exc
        if snapshot is not None and isinstance(snapshot.get("runtime"), dict):
            context.runtime_snapshot = snapshot["runtime"]
        context.before_manifest = manifest
        if "capture_before" in journal.completed_steps and (
            context.runtime_snapshot is None
            or context.before_manifest is None
            or not self.runtime.recovery_available(journal.operation_id)
        ):
            raise _environment_recovery_error(
                operation_id=journal.operation_id,
                cause="The interrupted environment switch lacks exact rollback evidence.",
            )


class _EnvironmentContext:
    def __init__(
        self,
        *,
        operation_id: str,
        request: EnvironmentSwitchRequest,
        previous: DeploymentConfig,
        candidate: DeploymentConfig,
        previous_target: ComposeTarget,
        target: ComposeTarget,
        prepared: tuple[ComposeTarget, Path, dict[str, str]],
        source_release: str,
        target_storage_identity: str,
        source_storage_identity: str,
        storage_changed: bool,
        probe_target_storage: bool,
        durable_completed_steps: tuple[str, ...],
        durable_step_outputs: Mapping[str, object],
    ) -> None:
        self.operation_id = operation_id
        self.request = request
        self.previous = previous
        self.candidate = candidate
        self.previous_target = previous_target
        self.target = target
        self.prepared = prepared
        self.source_release = source_release
        self.target_storage_identity = target_storage_identity
        self.source_storage_identity = source_storage_identity
        self.storage_changed = storage_changed
        self.probe_target_storage = probe_target_storage
        self.durable_completed_steps = frozenset(durable_completed_steps)
        self.durable_step_outputs = dict(durable_step_outputs)
        self.runtime_snapshot: Mapping[str, object] | None = None
        self.before_manifest: Mapping[str, object] | None = None
        self.rendered_path: Path | None = None


class _EnvironmentOperationGateway:
    def __init__(self, *, service: EnvironmentService, context: _EnvironmentContext) -> None:
        self.service = service
        self.context = context
        self.jobs_quiesced = False
        self.mutated = False
        self.after_manifest: Mapping[str, object] | None = None
        self.backup_result: BackupResult | None = None
        self.storage_inventory: StorageInventory | None = None
        self.preservation_verified = False
        self.target_release = context.source_release
        self.credential_provisioning_evidence: Mapping[str, object] = {}

    def postcondition_holds(
        self,
        _definition: LifecycleOperationDefinition,
        step: LifecycleOperationStep,
    ) -> bool:
        if step.step_id == "prepare_target_images":
            return False
        if step.step_id == "quiesce_jobs":
            return self.service.jobs.pause_owned(self.context.operation_id)
        if step.step_id == "capture_before":
            return bool(
                self.context.runtime_snapshot is not None
                and self.context.before_manifest is not None
                and self.service.runtime.recovery_available(self.context.operation_id)
            )
        if step.step_id == "create_backup":
            self.backup_result = self.service.backup.find_verified(self.context.operation_id)
            return self.backup_result is not None
        if step.step_id == "provision_storage_credentials":
            return self.service.storage.provisioning_matches(self.context.candidate)
        if step.step_id == "render_target":
            return self.service.configuration.transition_environment_matches(
                self.context.previous,
                self.context.candidate,
                self.context.prepared,
            )
        if step.step_id == "install_storage_credentials":
            return self.service.storage.credentials_match(
                self.context.candidate,
                self.context.prepared[1],
            )
        if step.step_id == "apply_runtime_artifacts":
            return self.service.runtime.artifacts_match(self.context.candidate)
        if step.step_id == "activate_target":
            try:
                holds = self.service.runtime.healthy(
                    self.context.candidate,
                    self.context.target,
                ) and (
                    self.service.runtime.runtime_release(
                        self.context.candidate,
                        self.context.target,
                    )
                    == self.context.source_release
                )
            except (OSError, RuntimeError, ValueError):
                holds = False
            self.mutated = holds or step.step_id in self.context.durable_completed_steps
            return holds
        if step.step_id == "verify_health":
            try:
                self.target_release = self.service.runtime.runtime_release(
                    self.context.candidate,
                    self.context.target,
                )
                return (
                    self.target_release == self.context.source_release
                    and self.service.runtime.healthy(
                        self.context.candidate,
                        self.context.target,
                    )
                )
            except (OSError, RuntimeError, ValueError):
                return False
        if step.step_id == "capture_after":
            try:
                self.after_manifest = self.service.runtime.load_manifest(
                    self.context.operation_id,
                    "after",
                )
            except (OSError, ValueError):
                return False
            return self.after_manifest is not None
        if step.step_id == "verify_preservation":
            if self.context.before_manifest is None or self.after_manifest is None:
                return False
            try:
                self.service.runtime.compare_environment_manifests(
                    self.context.before_manifest,
                    self.after_manifest,
                )
            except (OSError, RuntimeError, ValueError):
                return False
            self.preservation_verified = True
            return True
        if step.step_id == "mark_active":
            try:
                return self.service.configuration.active_publication_matches(
                    self.context.candidate,
                    self.context.prepared,
                )
            except Exception:
                return False
        if step.step_id == "resume_jobs":
            return not self.service.jobs.pause_owned(self.context.operation_id)
        return False

    def step_output(
        self,
        _definition: LifecycleOperationDefinition,
        step: LifecycleOperationStep,
    ) -> dict[str, object]:
        if step.step_id == "quiesce_jobs":
            return {
                "owner_operation_id": self.context.operation_id,
                "previously_paused": not self.jobs_quiesced,
            }
        if step.step_id == "capture_before":
            return {
                "recovery_snapshot_path": str(
                    self.service.lifecycle_state.previous_config_path(self.context.operation_id)
                ),
                "manifest_checksum": _mapping_checksum(self.context.before_manifest),
            }
        if step.step_id == "create_backup" and self.backup_result is not None:
            return {
                "path": self.backup_result.path,
                "size_bytes": self.backup_result.size_bytes,
                "evidence_checksum": _mapping_checksum(self.backup_result.model_dump(mode="json")),
            }
        if step.step_id == "provision_storage_credentials":
            return dict(self.credential_provisioning_evidence)
        if step.step_id == "render_target":
            path = self.context.rendered_path or self.context.prepared[1]
            return {
                "path": str(path),
                "sha256": _path_checksum(path),
            }
        if step.step_id == "install_storage_credentials":
            return dict(
                self.service.storage.credential_evidence(
                    self.context.candidate,
                    self.context.prepared[1],
                )
            )
        if step.step_id == "apply_runtime_artifacts":
            return {
                "candidate_checksum": _mapping_checksum(
                    self.context.candidate.model_dump(mode="json")
                ),
                "postcondition": self.service.runtime.artifacts_match(self.context.candidate),
            }
        if step.step_id in {"activate_target", "verify_health"}:
            return {
                "target_environment": self.context.candidate.environment,
                "release": self.target_release,
            }
        if step.step_id == "capture_after":
            return {"manifest_checksum": _mapping_checksum(self.after_manifest)}
        return {}

    def execute_step(
        self,
        definition: LifecycleOperationDefinition,
        step: LifecycleOperationStep,
        *,
        output_sink: TechnicalSink,
        heartbeat: HeartbeatSink,
        cancellation: CancellationToken,
    ) -> None:
        del output_sink
        try:
            self._execute(step.step_id, heartbeat=heartbeat, cancellation=cancellation)
        except LifecycleError as exc:
            self._handle_failure(exc)
        except StackGatewayError as exc:
            failure = LifecycleError.stable_failure(
                code=f"environment_{step.step_id}_failed",
                cause=exc.detail,
                remediation=(
                    "Inspect the lifecycle log, correct the reported dependency, and retry."
                ),
                step=step.step_id,
            )
            self._handle_failure(failure, cause=exc)
        except (OSError, RuntimeError, ValueError) as exc:
            failure = LifecycleError.stable_failure(
                code=f"environment_{step.step_id}_failed",
                cause="The environment transition gate failed.",
                remediation="Inspect the lifecycle log, correct the reported dependency, and retry.",
                step=step.step_id,
            )
            self._handle_failure(failure, cause=exc)
        except Exception as exc:
            failure = LifecycleError.internal(
                step=step.step_id,
                recovery_command=definition.recovery_command,
            )
            self._handle_failure(failure, cause=exc)
        except BaseException as exc:
            if not self.mutated:
                raise
            failure = LifecycleError.interrupted(
                step=step.step_id,
                recovery_command=definition.recovery_command,
                forced=True,
            )
            self._handle_failure(failure, cause=exc)

    def _execute(
        self,
        step_id: str,
        *,
        heartbeat: HeartbeatSink,
        cancellation: CancellationToken,
    ) -> None:
        if step_id == "prepare_target_images":
            self.service.runtime.prepare_target_images(
                self.context.candidate,
                self.context.target,
                self.context.prepared[2],
            )
            return
        if step_id == "quiesce_jobs":
            self.service.jobs.stop_accepting(self.context.operation_id)
            self.jobs_quiesced = True
            self.service.jobs.wait_for_idle(
                cancellation=cancellation,
                heartbeat=heartbeat,
            )
            return
        if step_id == "capture_before":
            if self.context.runtime_snapshot is None:
                self.context.runtime_snapshot = self.service.runtime.capture_recovery(
                    self.context.previous_target,
                    self.context.target,
                    operation_id=self.context.operation_id,
                )
            if self.context.before_manifest is None:
                self.context.before_manifest = self.service.runtime.capture_manifest(
                    self.context.previous,
                    self.context.previous_target,
                    operation_id=self.context.operation_id,
                    stage="before",
                )
            self.service.lifecycle_state.save_previous_config(
                self.context.operation_id,
                {
                    "configuration": self.context.previous.model_dump(mode="json"),
                    "runtime": dict(self.context.runtime_snapshot),
                },
            )
            return
        if step_id == "validate_preservation_baseline":
            if self.context.before_manifest is None:
                raise ValueError("Pre-transition preservation evidence is unavailable")
            self.service.runtime.validate_preservation_baseline(
                self.context.before_manifest,
            )
            return
        if step_id == "create_backup":
            self.backup_result = self.service.backup.create(
                BackupCreateRequest(operation_id=self.context.operation_id)
            )
            if (
                self.backup_result.verification_status is not BackupVerificationStatus.VERIFIED
                or self.backup_result.size_bytes <= 0
            ):
                raise LifecycleError.dependency(
                    code="environment_backup_unverified",
                    cause="The protected PostgreSQL backup was not verified.",
                    remediation="Repair backup configuration and retry.",
                    step="create_backup",
                )
            return
        if step_id == "provision_storage_credentials":
            self.mutated = True
            self.credential_provisioning_evidence = self.service.storage.provision_credentials(
                self.context.candidate
            )
            environment = self.service.storage.candidate_environment(self.context.candidate, {})
            prepared = self.service.configuration.prepare_transition_environment(
                self.context.previous,
                self.context.candidate,
                environment,
            )
            if prepared[0] != self.context.target or prepared[1] != self.context.prepared[1]:
                raise ValueError("Provisioning changed the selected target identity")
            self.context.prepared = prepared
            return
        if step_id == "validate_target":
            self.service.runtime.validate_target(
                self.context.candidate,
                self.context.target,
                self.context.prepared[2],
                managed_target=self.context.previous_target,
            )
            return
        if step_id == "inventory_storage":
            self.storage_inventory = self.service.storage.inventory(self.context.previous)
            return
        if step_id == "require_storage_decision":
            if self.storage_inventory is None:
                raise ValueError("Source storage inventory is unavailable")
            if (
                _storage_decision_required(self.storage_inventory)
                and self.context.request.artifact_decision is None
            ):
                raise _artifact_decision_required()
            return
        if step_id == "probe_target_storage":
            self.mutated = True
            self.service.storage.probe_write(
                self.context.candidate,
                self.context.prepared[2],
            )
            if cancellation.requested or cancellation.forced:
                raise LifecycleError.interrupted(
                    step=step_id,
                    recovery_command=(
                        "./flow-steward environment switch "
                        + self.context.previous.environment
                        + " --confirm"
                    ),
                    forced=cancellation.forced,
                )
            return
        if step_id == "render_target":
            self.mutated = True
            path = self.service.configuration.stage_transition_environment(
                self.context.previous,
                self.context.candidate,
                self.context.prepared,
            )
            self.context.rendered_path = path
            return
        if step_id == "install_storage_credentials":
            self.mutated = True
            self.service.storage.install_credentials(
                self.context.candidate,
                self.context.prepared[1],
            )
            return
        if step_id == "apply_runtime_artifacts":
            self.mutated = True
            self.service.runtime.apply_artifacts(
                self.context.candidate,
                operation_id=self.context.operation_id,
            )
            return
        if step_id == "activate_target":
            self.mutated = True
            if self.context.runtime_snapshot is None:
                raise ValueError("Exact runtime recovery inventory is unavailable")
            self.service.runtime.activate(
                self.context.previous,
                self.context.candidate,
                self.context.previous_target,
                self.context.target,
                self.context.runtime_snapshot,
            )
            return
        if step_id == "verify_health":
            if not self.service.runtime.healthy(
                self.context.candidate,
                self.context.target,
            ):
                raise RuntimeError("Target runtime health was not proven")
            self.target_release = self.service.runtime.runtime_release(
                self.context.candidate,
                self.context.target,
            )
            if self.target_release != self.context.source_release:
                raise RuntimeError("Target runtime release differs from the source release")
            return
        if step_id == "capture_after":
            self.after_manifest = self.service.runtime.capture_manifest(
                self.context.candidate,
                self.context.target,
                operation_id=self.context.operation_id,
                stage="after",
            )
            return
        if step_id == "verify_preservation":
            if self.context.before_manifest is None or self.after_manifest is None:
                raise ValueError("Preservation manifests are incomplete")
            self.service.runtime.compare_environment_manifests(
                self.context.before_manifest,
                self.after_manifest,
            )
            self.preservation_verified = True
            return
        if step_id == "mark_active":
            self.service.configuration.mark_active(
                self.context.previous,
                self.context.candidate,
                self.context.prepared,
            )
            return
        if step_id == "resume_jobs":
            self.service.jobs.resume_accepting(self.context.operation_id)
            self.jobs_quiesced = False
            return
        raise ValueError(f"Unknown environment step: {step_id}")

    def _handle_failure(
        self,
        failure: LifecycleError,
        *,
        cause: BaseException | None = None,
    ) -> NoReturn:
        if not self.mutated:
            if self.jobs_quiesced:
                try:
                    self.service.jobs.resume_accepting(self.context.operation_id)
                    self.jobs_quiesced = False
                except (OSError, RuntimeError, ValueError) as resume_exc:
                    raise LifecycleError.recovery_required(
                        code="environment_recovery_required",
                        cause="Job admission could not be restored after a failed preflight.",
                        remediation="Restore job admission before retrying.",
                        step="recovery",
                        recovery_command="flow-steward environment show",
                    ) from resume_exc
            raise failure from cause
        if self._restore_previous():
            if failure.code in {"lifecycle_cancelled", "lifecycle_forced_interrupt"}:
                raise failure from cause
            raise LifecycleError.stable_failure(
                code="environment_switch_failed",
                cause="The target environment failed; the exact previous runtime was restored.",
                remediation="Inspect the lifecycle log, correct the target, and retry.",
                step="recovery",
            ) from cause or failure
        raise LifecycleError.recovery_required(
            code="environment_recovery_required",
            cause=(
                "The target environment failed and exact previous runtime recovery was not "
                f"verified. Original failure: {failure.cause}"
            ),
            remediation="Inspect the lifecycle journal and restore the previous runtime.",
            step="recovery",
            recovery_command="flow-steward environment switch " + self.context.previous.environment,
        ) from cause or failure

    def _restore_previous(self) -> bool:
        snapshot = self.context.runtime_snapshot
        if snapshot is None or self.context.before_manifest is None:
            return False
        try:
            restored = self.service.runtime.restore_recovery(
                self.context.previous_target,
                operation_id=self.context.operation_id,
                snapshot=snapshot,
            )
            if not restored or not self.service.runtime.healthy(
                self.context.previous,
                self.context.previous_target,
            ):
                return False
            recovered = self.service.runtime.capture_manifest(
                self.context.previous,
                self.context.previous_target,
                operation_id=self.context.operation_id,
                stage="after",
            )
            self.service.runtime.compare_environment_manifests(
                self.context.before_manifest,
                recovered,
            )
            if self.jobs_quiesced:
                self.service.jobs.resume_accepting(self.context.operation_id)
                self.jobs_quiesced = False
            return True
        except Exception:
            return False


def _candidate(
    active: DeploymentConfig,
    request: EnvironmentSwitchRequest,
) -> DeploymentConfig:
    values = active.model_dump(mode="json")
    values["environment"] = request.target
    values["development_tools"] = (
        list(_COMPLETE_DEVELOPMENT_TOOLS) if request.target == "development" else []
    )
    if request.file_storage == "bundled":
        values["file_storage"] = "bundled"
    elif request.file_storage == "external_s3":
        values.update(
            {
                "file_storage": "external_s3",
                "s3_endpoint": request.s3_endpoint,
                "s3_bucket": request.s3_bucket,
                "s3_region": request.s3_region,
                "s3_credentials_path": request.s3_credentials_file,
                "allow_insecure_s3_http": request.allow_insecure_s3_http,
            }
        )
    return DeploymentConfig.model_validate(values)


def _environment_steps(
    storage_changed: bool,
    probe_target_storage: bool,
    provision_bundled_credentials: bool,
) -> tuple[LifecycleOperationStep, ...]:
    steps = [
        ("prepare_target_images", "Prepare target images while the source remains online"),
        ("quiesce_jobs", "Stop accepting new jobs and wait for active jobs"),
        ("capture_before", "Snapshot exact configuration, runtime, and preservation state"),
        (
            "validate_preservation_baseline",
            "Validate required preservation evidence before mutation",
        ),
        ("create_backup", "Create and verify protected PostgreSQL backup"),
    ]
    if provision_bundled_credentials:
        steps.append(
            (
                "provision_storage_credentials",
                "Provision the owner-only bundled storage identity",
            )
        )
    steps.append(("render_target", "Render target configuration without marking it active"))
    if storage_changed or provision_bundled_credentials:
        steps.append(("install_storage_credentials", "Install exact target storage credentials"))
    steps.append(("validate_target", "Render and validate the target Compose configuration"))
    if storage_changed:
        steps.extend(
            (
                ("inventory_storage", "Inventory source artifact storage"),
                ("require_storage_decision", "Require explicit artifact availability decision"),
            )
        )
    if probe_target_storage:
        steps.append(("probe_target_storage", "Probe target storage connectivity and write access"))
    steps.extend(
        (
            ("apply_runtime_artifacts", "Install target runtime artifacts"),
            ("activate_target", "Start target runtime at the installed release"),
            ("verify_health", "Verify canonical target runtime health and release"),
            ("capture_after", "Capture post-transition preservation state"),
            ("verify_preservation", "Compare exact preservation manifests"),
            ("mark_active", "Atomically publish the verified target environment revision"),
            ("resume_jobs", "Resume new job admission"),
        )
    )
    return tuple(
        LifecycleOperationStep(
            step_id=step_id,
            label=label,
            safe_boundary=step_id
            not in {
                "provision_storage_credentials",
                "render_target",
                "install_storage_credentials",
                "validate_target",
                "inventory_storage",
                "require_storage_decision",
                "probe_target_storage",
                "apply_runtime_artifacts",
                "activate_target",
                "verify_health",
                "capture_after",
                "verify_preservation",
                "mark_active",
            },
        )
        for step_id, label in steps
    )


def _retained_resources(
    previous: DeploymentConfig,
    target: ComposeTarget,
) -> tuple[str, ...]:
    retained = ["artifact_rows"]
    if previous.file_storage == "bundled":
        retained.append(f"bundled_volume:{target.project_name}:seaweedfs")
    return tuple(retained)


def _environment_recovery_error(*, operation_id: str, cause: str) -> LifecycleError:
    failure = LifecycleError.recovery_required(
        code="environment_recovery_required",
        cause=cause,
        remediation="Inspect the lifecycle journal and reconcile the previous runtime.",
        step="recovery",
        recovery_command="flow-steward environment show",
    )
    failure.operation_id = operation_id
    return failure


def _storage_decision_required(inventory: StorageInventory) -> bool:
    return inventory.completeness != "complete" or (inventory.approximate_count or 0) > 0


def _artifact_decision_required(
    inventory: StorageInventory | None = None,
) -> LifecycleError:
    return LifecycleError(
        code="environment_artifact_decision_required",
        summary="An explicit artifact availability decision is required.",
        cause="The source storage contains artifacts or its inventory is unknown.",
        remediation="Choose already_copied or accept_unavailable after reviewing the inventory.",
        retryable=False,
        step="storage_decision",
        exit_code=ExitCode.VALIDATION,
        details={
            "source_storage_inventory": (
                inventory.model_dump(mode="json") if inventory is not None else None
            )
        },
    )


def _mapping_checksum(value: object) -> str:
    payload = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _path_checksum(path: Path) -> str:
    try:
        return hashlib.sha256(path.read_bytes()).hexdigest()
    except OSError:
        return ""


__all__ = [
    "EnvironmentResult",
    "EnvironmentService",
    "EnvironmentShowRequest",
    "EnvironmentSwitchRequest",
    "StorageInventory",
]
