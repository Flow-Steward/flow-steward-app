"""Task-domain public command specifications."""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field, field_validator

from core.application.management.command_models import ProjectTaskEnqueueResultView
from core.application.management.command_specs.contracts import (
    CommandSpec,
    FieldSpec,
    FieldType,
    InteractivePolicy,
    OperationType,
)
from core.application.management.json_safety import validate_no_sensitive_json_keys

_MESSAGE_VALUE_MUST_BE_A_JSON_OBJECT = "value must be a JSON object"
_TOKEN_TASKS_SUBMIT = "tasks.submit"

_PUBLIC_TASK_EXTRA_STATE_FIELDS = frozenset({"description", "origin", "priority", "task_type"})


class TaskSubmitCommandInput(BaseModel):
    """Validated input for submitting one task through the public CLI."""

    model_config = ConfigDict(extra="forbid")

    project_id: str
    task_summary: str
    # validate_default: a mode="before" validator is skipped for an absent field,
    # so without this the minting below never runs for the case it exists for.
    task_id: str = Field(default="", validate_default=True)
    workflow_id: str
    mode: str = ""
    test_mode: bool = False
    task_source: str = "manual"
    entry_path: str = "manual_api"
    inputs: dict[str, Any] = Field(default_factory=dict)
    extra_state: dict[str, Any] = Field(default_factory=dict)

    @field_validator("task_id", mode="before")
    @classmethod
    def mint_correlation_id_when_absent(cls, value: object) -> str:
        """Supply the caller correlation id the service requires.

        AC17-R92, finding D: task_id is a required caller correlation identifier at
        the service boundary, and the CLI let an empty one through. A human running
        `tasks submit` then got the service's raw validation dump -- the internal
        model name ProjectTaskEnqueueInput, the pydantic error code and a link to
        errors.pydantic.dev -- for a field the help did not mark required and that
        they have no reason to invent. A correlation id exists for a caller that
        wants to recognise its own submission; when nobody asks for one, minting it
        is the answer, not demanding it.
        """
        normalized = str(value or "").strip()
        return normalized or f"cli-{uuid4().hex[:16]}"

    @field_validator("project_id", "task_summary", "workflow_id")
    @classmethod
    def require_text(cls, value: str) -> str:
        normalized = str(value or "").strip()
        if not normalized:
            raise ValueError("value is required")
        return normalized

    @field_validator("extra_state", mode="before")
    @classmethod
    def parse_json_object(cls, value: object) -> dict[str, Any]:
        parsed = validate_no_sensitive_json_keys(_json_object(value), field_name="value")
        unsupported = sorted(set(parsed) - _PUBLIC_TASK_EXTRA_STATE_FIELDS)
        if unsupported:
            raise ValueError(
                "extra_state may only contain public annotations: "
                + ", ".join(sorted(_PUBLIC_TASK_EXTRA_STATE_FIELDS))
            )
        return parsed

    @field_validator("inputs", mode="before")
    @classmethod
    def parse_workflow_inputs(cls, value: object) -> dict[str, Any]:
        return validate_no_sensitive_json_keys(_json_object(value), field_name="value")


_PROJECT_ID_FIELD = FieldSpec(
    key="project_id",
    label="Project",
    type=FieldType.SINGLE_SELECT,
    required=True,
    choice_provider="projects.available",
    option_name="--project-id",
)


TASK_COMMAND_SPECS: tuple[CommandSpec, ...] = (
    CommandSpec(
        command_id=_TOKEN_TASKS_SUBMIT,
        path=("tasks", "submit"),
        summary="Submit a task.",
        description="Submit one manual task to a provisioned project workflow.",
        examples=(
            "flow-steward tasks submit --project-id proj_123 "
            "--workflow-id release-report --summary 'Generate the release report'",
        ),
        operation_type=OperationType.CHANGE,
        interactive_policy=InteractivePolicy.ALWAYS_REVIEW,
        fields=(
            _PROJECT_ID_FIELD,
            FieldSpec(
                key="workflow_id",
                label="Workflow id",
                type=FieldType.RUNTIME_IDENTIFIER,
                required=True,
                option_name="--workflow-id",
            ),
            FieldSpec(
                key="task_summary",
                label="Summary",
                type=FieldType.TEXT,
                required=True,
                option_name="--summary",
            ),
            FieldSpec(
                key="task_id",
                label="Task id",
                type=FieldType.RUNTIME_IDENTIFIER,
                advanced=True,
                option_name="--task-id",
                description=(
                    "Caller correlation identifier for this submission. Generated when "
                    "you do not supply one."
                ),
            ),
            FieldSpec(
                key="task_source",
                label="Source",
                type=FieldType.TEXT,
                advanced=True,
                default="manual",
                option_name="--source",
            ),
            FieldSpec(
                key="entry_path",
                label="Entry path",
                type=FieldType.RUNTIME_IDENTIFIER,
                advanced=True,
                default="manual_api",
                option_name="--entry-path",
            ),
            FieldSpec(
                key="mode",
                label="Mode",
                type=FieldType.RUNTIME_IDENTIFIER,
                advanced=True,
                option_name="--mode",
            ),
            FieldSpec(
                key="test_mode",
                label="Test mode",
                type=FieldType.BOOLEAN,
                advanced=True,
                default=False,
                option_name="--test-mode",
            ),
            FieldSpec(
                key="inputs",
                label="Workflow inputs",
                type=FieldType.TEXT,
                advanced=True,
                default={},
                option_name="--inputs",
                description="JSON object validated against the selected workflow input contract.",
                examples=('{"project_name":"Flow Steward App"}',),
            ),
            FieldSpec(
                key="extra_state",
                label="Extra state",
                type=FieldType.TEXT,
                advanced=True,
                default={},
                option_name="--extra-state",
                description="JSON object containing public task annotations.",
            ),
        ),
        input_model=TaskSubmitCommandInput,
        result_model=ProjectTaskEnqueueResultView,
        plan_builder_ref=None,
        confirmation_policy_ref=None,
        service_ref=_TOKEN_TASKS_SUBMIT,
        result_renderer_ref=_TOKEN_TASKS_SUBMIT,
    ),
)


def _json_object(value: object) -> dict[str, Any]:
    if value in (None, ""):
        return {}
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError as exc:
            raise ValueError(_MESSAGE_VALUE_MUST_BE_A_JSON_OBJECT) from exc
        if not isinstance(parsed, dict):
            raise ValueError(_MESSAGE_VALUE_MUST_BE_A_JSON_OBJECT)
        return dict(parsed)
    if isinstance(value, Mapping):
        return dict(value)
    raise ValueError(_MESSAGE_VALUE_MUST_BE_A_JSON_OBJECT)
