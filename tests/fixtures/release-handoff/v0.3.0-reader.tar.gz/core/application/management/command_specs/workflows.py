"""Workflow-domain public command specifications."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, field_validator

from core.application.management.command_specs.contracts import (
    CommandSpec,
    FieldSpec,
    FieldType,
    InteractivePolicy,
    OperationType,
)
from core.application.management.query_models import (
    ProjectWorkflowCatalogView,
    ProjectWorkflowEntrypointsView,
    WorkflowContractResultView,
    WorkflowSuggestionsResultView,
    WorkflowValidationResultView,
)

_TOKEN_WORKFLOWS_LIST = "workflows.list"
_TOKEN_WORKFLOWS_ENTRYPOINTS = "workflows.entrypoints"
_TOKEN_WORKFLOWS_VALIDATE = "workflows.validate"
_TOKEN_WORKFLOWS_CONTRACT = "workflows.contract"
_TOKEN_WORKFLOWS_SUGGESTIONS = "workflows.suggestions"


class WorkflowListCommandInput(BaseModel):
    """Validated input for workflow catalog queries."""

    model_config = ConfigDict(extra="forbid")

    project_id: str
    include_disabled: bool = False
    include_validation: bool = False


class WorkflowEntrypointsCommandInput(BaseModel):
    """Validated input for workflow entrypoint queries."""

    model_config = ConfigDict(extra="forbid")

    project_id: str
    include_disabled: bool = False


class WorkflowTargetCommandInput(BaseModel):
    """Validated input for one project workflow target."""

    model_config = ConfigDict(extra="forbid")

    project_id: str
    workflow_id: str

    @field_validator("workflow_id")
    @classmethod
    def require_workflow_id(cls, value: str) -> str:
        normalized = str(value or "").strip()
        if not normalized:
            raise ValueError("workflow_id is required")
        return normalized


_PROJECT_ID_FIELD = FieldSpec(
    key="project_id",
    label="Project",
    type=FieldType.SINGLE_SELECT,
    required=True,
    description="Project whose linked workflows or entrypoints should be queried.",
    examples=("proj_01J8K4M2Q7",),
    choice_provider="projects.available",
    option_name="--project-id",
)

_WORKFLOW_ID_FIELD = FieldSpec(
    key="workflow_id",
    label="Workflow id",
    type=FieldType.RUNTIME_IDENTIFIER,
    required=True,
    description="Identifier of the linked workflow to inspect.",
    examples=("release-report",),
    positional=True,
)


WORKFLOW_COMMAND_SPECS: tuple[CommandSpec, ...] = (
    CommandSpec(
        command_id=_TOKEN_WORKFLOWS_LIST,
        path=("workflows", "list"),
        summary="List workflows linked to a project.",
        description="List workflows linked to one project through the shared workflow operator service.",
        examples=("flow-steward workflows list --project-id proj_123",),
        operation_type=OperationType.READ,
        interactive_policy=InteractivePolicy.IMMEDIATE,
        fields=(
            _PROJECT_ID_FIELD,
            FieldSpec(
                key="include_disabled",
                label="Include disabled",
                type=FieldType.BOOLEAN,
                description="Include workflows that are currently disabled for the project.",
                examples=("true",),
                default=False,
                option_name="--include-disabled",
            ),
            FieldSpec(
                key="include_validation",
                label="Include validation",
                type=FieldType.BOOLEAN,
                description="Attach structured readiness and contract validation to each workflow.",
                examples=("true",),
                default=False,
                option_name="--include-validation",
            ),
        ),
        input_model=WorkflowListCommandInput,
        result_model=ProjectWorkflowCatalogView,
        plan_builder_ref=None,
        confirmation_policy_ref=None,
        service_ref=_TOKEN_WORKFLOWS_LIST,
        result_renderer_ref=_TOKEN_WORKFLOWS_LIST,
    ),
    CommandSpec(
        command_id=_TOKEN_WORKFLOWS_ENTRYPOINTS,
        path=("workflows", "entrypoints"),
        summary="List workflow entrypoints.",
        description="List callable workflow entrypoints for one project.",
        examples=("flow-steward workflows entrypoints --project-id proj_123",),
        operation_type=OperationType.READ,
        interactive_policy=InteractivePolicy.IMMEDIATE,
        fields=(
            _PROJECT_ID_FIELD,
            FieldSpec(
                key="include_disabled",
                label="Include disabled",
                type=FieldType.BOOLEAN,
                description="Include callable entrypoints that are currently disabled.",
                examples=("true",),
                default=False,
                option_name="--include-disabled",
            ),
        ),
        input_model=WorkflowEntrypointsCommandInput,
        result_model=ProjectWorkflowEntrypointsView,
        plan_builder_ref=None,
        confirmation_policy_ref=None,
        service_ref=_TOKEN_WORKFLOWS_ENTRYPOINTS,
        result_renderer_ref=_TOKEN_WORKFLOWS_ENTRYPOINTS,
    ),
    CommandSpec(
        command_id=_TOKEN_WORKFLOWS_VALIDATE,
        path=("workflows", "validate"),
        summary="Validate a workflow.",
        description="Validate one workflow linked to a project using structured workflow validation.",
        examples=("flow-steward workflows validate --project-id proj_123 release-report",),
        operation_type=OperationType.READ,
        interactive_policy=InteractivePolicy.IMMEDIATE,
        fields=(_PROJECT_ID_FIELD, _WORKFLOW_ID_FIELD),
        input_model=WorkflowTargetCommandInput,
        result_model=WorkflowValidationResultView,
        plan_builder_ref=None,
        confirmation_policy_ref=None,
        service_ref=_TOKEN_WORKFLOWS_VALIDATE,
        result_renderer_ref=_TOKEN_WORKFLOWS_VALIDATE,
    ),
    CommandSpec(
        command_id=_TOKEN_WORKFLOWS_CONTRACT,
        path=("workflows", "contract"),
        summary="Show a workflow contract.",
        description="Return the machine-readable contract for one linked workflow.",
        examples=("flow-steward workflows contract --project-id proj_123 release-report",),
        operation_type=OperationType.READ,
        interactive_policy=InteractivePolicy.IMMEDIATE,
        fields=(_PROJECT_ID_FIELD, _WORKFLOW_ID_FIELD),
        input_model=WorkflowTargetCommandInput,
        result_model=WorkflowContractResultView,
        plan_builder_ref=None,
        confirmation_policy_ref=None,
        service_ref=_TOKEN_WORKFLOWS_CONTRACT,
        result_renderer_ref=_TOKEN_WORKFLOWS_CONTRACT,
    ),
    CommandSpec(
        command_id=_TOKEN_WORKFLOWS_SUGGESTIONS,
        path=("workflows", "suggestions"),
        summary="Show workflow repair suggestions.",
        description="Return structured repair suggestions for one linked workflow.",
        examples=("flow-steward workflows suggestions --project-id proj_123 release-report",),
        operation_type=OperationType.READ,
        interactive_policy=InteractivePolicy.IMMEDIATE,
        fields=(_PROJECT_ID_FIELD, _WORKFLOW_ID_FIELD),
        input_model=WorkflowTargetCommandInput,
        result_model=WorkflowSuggestionsResultView,
        plan_builder_ref=None,
        confirmation_policy_ref=None,
        service_ref=_TOKEN_WORKFLOWS_SUGGESTIONS,
        result_renderer_ref=_TOKEN_WORKFLOWS_SUGGESTIONS,
    ),
)
