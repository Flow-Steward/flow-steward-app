"""Canonical technical infrastructure package."""
